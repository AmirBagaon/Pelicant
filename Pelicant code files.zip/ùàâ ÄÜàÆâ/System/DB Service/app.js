"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let express = require('express');
let path = require('path');
let logger = require('morgan');
let cookieParser = require('cookie-parser');
let bodyParser = require('body-parser');
let cors = require("cors");
const Connect_1 = require("./Connection/Connect");
const BoatRouter_1 = require("./Routes/BoatRouter");
const CameraRouter_1 = require("./Routes/CameraRouter");
const MapObjectRouter_1 = require("./Routes/MapObjectRouter");
const PoolRouter_1 = require("./Routes/PoolRouter");
const UserRouter_1 = require("./Routes/UserRouter");
const UserActionRouter_1 = require("./Routes/UserActionRouter");
const HitRouter_1 = require("./Routes/HitRouter");
let connection = new Connect_1.MongoConnection();
var app = express();
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(cors());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use("/user", UserRouter_1.UserRouter.Router);
app.use("/camera", CameraRouter_1.CameraRouter.Router);
app.use("/boat", BoatRouter_1.BoatRouter.Router);
app.use("/pool", PoolRouter_1.PoolRouter.Router);
app.use("/mapObject", MapObjectRouter_1.MapObjectRouter.Router);
app.use("/userAction", UserActionRouter_1.UserActionRouter.Router);
app.use("/hitId", HitRouter_1.HitRouter.Router);
app.use((req, res, next) => {
    let err = new Error('Not Found');
    err.status = 404;
    next(err);
});
app.use(function (err, req, res, next) {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    res.status(err.status || 500).send(req.app.get('env') === 'development' ? err : GiveClientErrorMessage(err.name));
});
module.exports = app;
process.on('exit', function () {
    connection.Destroy();
});
function GiveClientErrorMessage(errorMessageName) {
}
//# sourceMappingURL=app.js.map