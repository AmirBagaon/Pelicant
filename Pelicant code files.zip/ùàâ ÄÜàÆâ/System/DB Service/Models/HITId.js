"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let hitIdSchema = new mongoose_1.Schema({
    hitId: String
});
exports.HitIdModel = mongoose_1.model("hitId", hitIdSchema);
//# sourceMappingURL=HITId.js.map