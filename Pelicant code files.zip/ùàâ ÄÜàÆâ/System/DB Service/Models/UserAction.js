"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let userActionSchema = new mongoose_1.Schema({
    userId: String,
    pool: String,
    actions: { type: Array, default: [] },
    date: { type: Date, default: Date.now }
});
exports.UserActionModel = mongoose_1.model("userAction", userActionSchema);
//# sourceMappingURL=UserAction.js.map