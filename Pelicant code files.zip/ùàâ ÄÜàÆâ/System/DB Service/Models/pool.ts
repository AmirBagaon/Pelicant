import { Schema, model } from "mongoose"
import { LatLng } from "./mapObject";

let poolSchema = new Schema({
    poolId: String,
    poolName: String,
    mapImage: String,
    waterLevel: Number,
    location: LatLng,
    bounds: { type : Array , default : [] } // [{LatLng: {lat: Number, lng: Number}}],
});

export let PoolModel = model("pool", poolSchema);

// For typing
export interface IPoolModel{
    poolId: string;
    poolName: string;
    mapImage: string;
    waterLevel: number;
    location: LatLng;
    bounds: Array<LatLng>;
}