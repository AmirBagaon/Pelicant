"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let boatSchema = new mongoose_1.Schema({
    ip: String,
    poolId: String,
    locationX: String,
    locationY: String,
    destination: String
});
exports.BoatModel = mongoose_1.model("boat", boatSchema);
//# sourceMappingURL=boat.js.map