"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let userSchema = new mongoose_1.Schema({
    userId: String,
    email: String,
    userName: { type: String, default: "" },
    password: { type: String, default: "" },
    isAdmin: Boolean,
    rank: String,
    pools: [String],
    party: String,
});
exports.UserModel = mongoose_1.model("user", userSchema);
//# sourceMappingURL=User.js.map