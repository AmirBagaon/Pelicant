import { Schema, model } from "mongoose"
import { LatLng } from "./mapObject";

let cameraSchema = new Schema({
    cameraId: String,
    coordinates: {
        lat: Number,
        lang: Number
    },
    fieldOfVision: { type : Array , default : [] },//[{lat: Number, lng: Number}],
    ip: String,
    status: String,
    poolId: String
});

export let CameraModel = model("camera", cameraSchema);

// For typing
export interface ICameraModel{
    cameraId: string;
    coordinates: {
        lat: number,
        lang: number
    };
    fieldOfVision: Array<LatLng>;
    ip: string;
    status: String;
    poolId: string;
}