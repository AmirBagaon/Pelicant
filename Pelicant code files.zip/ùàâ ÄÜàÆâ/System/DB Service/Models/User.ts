import { Schema, model } from "mongoose"

let userSchema = new Schema({
    userId: String,
    email: String,
    userName: {type: String, default: ""},
    password: {type: String, default: ""},
    isAdmin: Boolean,
    rank: String,
    pools: [String],
    party: String, //Am

});

export let UserModel = model("user", userSchema);

// For typing
export interface IUserModel{
    userId: string;
    email: string;
    userName: string;
    password: string;
    isAdmin: boolean;
    rank: string;
    pools: Array<String>;
    party: string; // Am
}