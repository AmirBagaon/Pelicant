"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let cameraSchema = new mongoose_1.Schema({
    cameraId: String,
    coordinates: {
        lat: Number,
        lang: Number
    },
    fieldOfVision: { type: Array, default: [] },
    ip: String,
    status: String,
    poolId: String
});
exports.CameraModel = mongoose_1.model("camera", cameraSchema);
//# sourceMappingURL=camera.js.map