import { Schema, model } from "mongoose"
let mongoose = require("mongoose")

export class LatLng {

    lat: number;
    lng: number;
    constructor(lat: number, lng: number) {
        this.lat = lat;
        this.lng = lng;
    }

    toBSON() {
        return {
            lat: this.lat,
            lng: this.lng
        }
    }
}
  
class LatLngSchema extends mongoose.SchemaType {
    
    cast(lat: number, lng: number) {
        return new LatLng(lat, lng);
    }
}

mongoose.Schema.Types.LatLng = LatLngSchema;

let mapObjectSchema = new Schema({
    mapObjecId: String,
    poolId: String,
    type: String,
    loctaion: LatLng,
    polygon: { type : Array , default : [] }
});

export let MapObjectModel = model("mapObject", mapObjectSchema);

// For typing
export interface IMapObjectModel{
    mapObjecId: string;
    poolId: string;
    type: string;
    location: LatLng;
    polygon: Array<LatLng>;
}