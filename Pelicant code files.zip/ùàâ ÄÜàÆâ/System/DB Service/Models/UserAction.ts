import { Schema, model } from "mongoose"
import { LatLng } from "./mapObject"


let userActionSchema = new Schema({
    userId: String,
    pool: String,
    actions: { type : Array , default : [] },
    date: { type: Date, default: Date.now }
});

export let UserActionModel = model("userAction", userActionSchema);

// For typing
export interface IAction {
    time: Number;
    latlngs: Array<LatLng>;
}

export interface IUserAction{
    userId: String;
    pool: String;
    actions: Array<IAction>;
    date: Date;
}