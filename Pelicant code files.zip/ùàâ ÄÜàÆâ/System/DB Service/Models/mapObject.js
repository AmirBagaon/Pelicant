"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let mongoose = require("mongoose");
class LatLng {
    constructor(lat, lng) {
        this.lat = lat;
        this.lng = lng;
    }
    toBSON() {
        return {
            lat: this.lat,
            lng: this.lng
        };
    }
}
exports.LatLng = LatLng;
class LatLngSchema extends mongoose.SchemaType {
    cast(lat, lng) {
        return new LatLng(lat, lng);
    }
}
mongoose.Schema.Types.LatLng = LatLngSchema;
let mapObjectSchema = new mongoose_1.Schema({
    mapObjecId: String,
    poolId: String,
    type: String,
    loctaion: LatLng,
    polygon: { type: Array, default: [] }
});
exports.MapObjectModel = mongoose_1.model("mapObject", mapObjectSchema);
//# sourceMappingURL=mapObject.js.map