"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mapObject_1 = require("./mapObject");
let poolSchema = new mongoose_1.Schema({
    poolId: String,
    poolName: String,
    mapImage: String,
    waterLevel: Number,
    location: mapObject_1.LatLng,
    bounds: { type: Array, default: [] }
});
exports.PoolModel = mongoose_1.model("pool", poolSchema);
//# sourceMappingURL=pool.js.map