import { Schema, model } from "mongoose"
import { LatLng } from "./mapObject";

// let boatSchema = new Schema({
//     boatId: String,
//     poolId: String,
//     lactaion: LatLng,
//     ip: String,
//     status: String,
//     assignedUserId: String
// });

//Am
let boatSchema = new Schema({
    // _id: String,
    ip: String,
    poolId: String,    
    locationX: String,
    locationY: String,
    destination: String
    //     status: String,
//     assignedUserId: String
});


export let BoatModel = model("boat", boatSchema);

// For typing
// export interface IBoatModel{
//     boatId: string;
//     poolId: string;
//     location: LatLng;
//     ip: String;
//     status: String;
//     assignedUserId: string;
// }

//AM
export interface IBoatModel{
    // _id: String;
    ip: String;
    poolId: String;    
    locationX: String;
    locationY: String;
    destination: String;
//    status: String;
 //   assignedUserId: string;
}
