import { Schema, model } from "mongoose"
import { LatLng } from "./mapObject"

let hitIdSchema = new Schema({
    hitId: String
});

export let HitIdModel = model("hitId", hitIdSchema);

// For typing
export interface IHitId {
    hitId: String;
}