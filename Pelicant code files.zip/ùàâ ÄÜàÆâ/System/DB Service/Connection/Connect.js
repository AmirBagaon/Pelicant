"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let mongoose = require("mongoose");
const Mongo_config_1 = require("../Configurations/Mongo.config");
class MongoConnection {
    constructor() {
        mongoose.Promise = global.Promise;
        mongoose.connect(`mongodb://${Mongo_config_1.default.db.userName}:${Mongo_config_1.default.db.password}@${Mongo_config_1.default.db.connectionString}`, {
            useMongoClient: true,
            reconnectTries: Number.MAX_VALUE,
            reconnectInterval: 500,
            poolSize: 10,
            bufferMaxEntries: 0,
            keepAlive: 120
        }, (err) => {
            if (err) {
                console.error(err);
            }
            else {
                console.log("Connection opened");
            }
        });
    }
    Destroy() {
        mongoose.connection.close();
        mongoose.connection.on("diconnected", (data) => {
            console.log("Connection successfully closed");
        });
    }
}
exports.MongoConnection = MongoConnection;
//# sourceMappingURL=Connect.js.map