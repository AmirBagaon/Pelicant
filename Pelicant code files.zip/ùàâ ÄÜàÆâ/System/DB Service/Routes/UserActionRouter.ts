import { ApiRouterBase, ROUTE_METHOD, IRoute } from "./ApiRouter";
import {Model, Document} from "mongoose";
import {UserActionModel} from "../Models/UserAction";

export class UserActionRouter extends ApiRouterBase{

    private constructor(collection: Model<Document>, ...specialRoutes:Array<IRoute>){
        super(collection, ...specialRoutes);
    }

    public static get Router(){
        if(!this._self){
            this._self = new UserActionRouter(UserActionModel);
        }

        return this._self.router;
    }
}