import { ApiRouterBase, ROUTE_METHOD, IRoute } from "./ApiRouter";
import {Model, Document} from "mongoose";
import {BoatModel} from "../Models/boat";

export class BoatRouter extends ApiRouterBase{

    private constructor(collection: Model<Document>, ...specialRoutes:Array<IRoute>){
        super(collection, ...specialRoutes);
    }

    public static get Router(){
        if(!this._self){

            // Remove this test path afterwards- This is an example
            this._self = new BoatRouter(BoatModel, {path:"/test", method: ROUTE_METHOD.GET, route: (req, res, next)=>{
                res.send("Okay")
            }});
        }
        //Am
        // public static get Router(){
        //     if(!this._self){
        //         this._self = new BoatRouter(BoatModel);
        //     }
    
        //     return this._self.router;
        // }



        return this._self.router;
    }
}