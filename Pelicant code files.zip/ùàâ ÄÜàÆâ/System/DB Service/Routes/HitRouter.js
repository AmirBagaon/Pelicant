"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const HITId_1 = require("../Models/HITId");
class HitRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new HitRouter(HITId_1.HitIdModel);
        }
        return this._self.router;
    }
}
exports.HitRouter = HitRouter;
//# sourceMappingURL=HitRouter.js.map