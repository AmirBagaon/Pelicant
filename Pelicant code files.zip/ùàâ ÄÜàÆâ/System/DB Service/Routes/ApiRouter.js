"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
class ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        this.collection = collection;
        this._router = express_1.Router();
        this.Init(specialRoutes);
    }
    get router() {
        return this._router;
    }
    Init(specialRoutes) {
        let routes = [];
        routes.push({ path: "/", method: ROUTE_METHOD.GET, route: (req, res, next) => {
                console.log('in get1');
                this.collection.find({})
                    .then(doc => res.send(doc))
                    .catch(err => next(err));
            } });
        routes.push({ path: "/filter/:propertyName/:value", method: ROUTE_METHOD.GET, route: (req, res, next) => {
                console.log('in get2');
                let query = {};
                query[req.params.propertyName] = req.params.value;
                this.collection.find(query)
                    .then(doc => res.send(doc))
                    .catch(err => next(err));
            } });
        routes.push({ path: "/", method: ROUTE_METHOD.POST, route: (req, res, next) => {
                let doc = new this.collection(req.body);
                doc.validate()
                    .then(() => {
                    doc.save()
                        .then((data) => res.status(201).send(data))
                        .catch(err => next(err));
                })
                    .catch(err => next(err));
            } });
        routes.push({ path: "/", method: ROUTE_METHOD.DELETE, route: (req, res, next) => {
                let query = req.body;
                this.collection.remove(query)
                    .then(() => res.status(204).send())
                    .catch(err => next(err));
            } });
        routes.push({ path: "/add", method: ROUTE_METHOD.POST, route: (req, res, next) => {
                let body = req.body;
                let arr = [];
                arr.push();
                this.collection.findOne({ userId: body.userId, date: body.date })
                    .then(document => {
                    let tmp = document['actions'];
                    document['actions'] = [];
                    tmp = tmp.concat(body.actions);
                    document['actions'] = tmp;
                    document.save().then(val => {
                        res.status(202).send(val);
                    }).catch(err => {
                        err.status = 400;
                        next(err);
                    });
                }).catch(err => {
                    err.status = 500;
                    next(err);
                });
            } });
        routes.push({ path: "/filter/:propertyName/:value", method: ROUTE_METHOD.PUT, route: (req, res, next) => {
                console.log('in put2');
                console.log(req.params.propertyName);
                console.log(req.params.value);
                let query = {};
                query[req.params.propertyName] = req.params.value;
                let body = req.body;
                let id;
                let doc = {};
                console.log(body);
                for (let prop in body) {
                    if (prop === "_id") {
                        id = body[prop];
                    }
                    else {
                        doc[prop] = body[prop];
                    }
                }
                console.log(doc);
                this.collection.findOne(query)
                    .then(documenttt => {
                    console.log("was found");
                    for (let prop in doc) {
                        documenttt[prop] = doc[prop];
                    }
                    documenttt.save().then(val => {
                        res.status(202).send(val);
                    }).catch(err => {
                        err.status = 400;
                        next(err);
                    });
                })
                    .catch(err => next(err));
            } });
        routes.push({ path: "/", method: ROUTE_METHOD.PUT, route: (req, res, next) => {
                console.log("in put 1");
                let body = req.body;
                console.log("body:");
                console.log(body);
                let id;
                let doc = {};
                for (let prop in body) {
                    if (prop === "_id") {
                        id = body[prop];
                    }
                    else {
                        doc[prop] = body[prop];
                    }
                }
                console.log("doc:");
                console.log(doc);
                this.collection.findById(id).then(document => {
                    console.log("was found!");
                    console.log("document before:");
                    console.log(document);
                    console.log("doc:");
                    console.log(doc);
                    for (let prop in doc) {
                        document[prop] = doc[prop];
                    }
                    console.log("document after:");
                    console.log(document);
                    document.save().then(val => {
                        res.status(202).send(val);
                    }).catch(err => {
                        console.log("unable to save");
                        err.status = 400;
                        next(err);
                    });
                }).catch(err => {
                    console.log("unable to find");
                    err.status = 500;
                    next(err);
                });
            } });
        for (let specialRoute of specialRoutes) {
            routes.push(specialRoute);
        }
        this.BuildRouter(routes);
    }
    BuildRouter(routes) {
        for (let route of routes) {
            switch (route.method) {
                case ROUTE_METHOD.GET:
                    this._router.get(route.path, route.route);
                    break;
                case ROUTE_METHOD.POST:
                    this._router.post(route.path, route.route);
                    break;
                case ROUTE_METHOD.DELETE:
                    this._router.delete(route.path, route.route);
                    break;
                case ROUTE_METHOD.PUT:
                    this._router.put(route.path, route.route);
                    break;
            }
        }
    }
}
exports.ApiRouterBase = ApiRouterBase;
var ROUTE_METHOD;
(function (ROUTE_METHOD) {
    ROUTE_METHOD[ROUTE_METHOD["POST"] = 0] = "POST";
    ROUTE_METHOD[ROUTE_METHOD["GET"] = 1] = "GET";
    ROUTE_METHOD[ROUTE_METHOD["PUT"] = 2] = "PUT";
    ROUTE_METHOD[ROUTE_METHOD["DELETE"] = 3] = "DELETE";
})(ROUTE_METHOD = exports.ROUTE_METHOD || (exports.ROUTE_METHOD = {}));
//# sourceMappingURL=ApiRouter.js.map