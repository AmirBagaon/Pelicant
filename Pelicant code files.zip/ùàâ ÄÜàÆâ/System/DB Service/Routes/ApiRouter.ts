import {Model, Document} from "mongoose"
import {Router, Request, Response, NextFunction} from "express"

export abstract class ApiRouterBase{
    protected static _self: ApiRouterBase;
    protected _router: Router;

    public get router(){
        return this._router;
    }

    constructor(protected collection:Model<Document>, ...specialRoutes:Array<IRoute>){
        this._router = Router();

        this.Init(specialRoutes);
    }
     
    private Init(specialRoutes:Array<IRoute>){
        let routes: Array<IRoute> = [];
        

        // Get all
        routes.push({path:"/", method: ROUTE_METHOD.GET, route:(req, res, next)=>{
            console.log('in get1');
            this.collection.find({})
            .then(doc=> res.send(doc))
            .catch(err=>next(err));
        }});

        // Get by property
        routes.push({path:"/filter/:propertyName/:value", method: ROUTE_METHOD.GET, route: (req, res, next)=>{
            console.log('in get2');
            let query:any = {};
            query[req.params.propertyName] = req.params.value;
            this.collection.find(query)
            .then(doc=> res.send(doc))
            .catch(err=>next(err));
        }});

        // Saves a document
        routes.push({path: "/", method: ROUTE_METHOD.POST, route:(req, res, next)=>{
            let doc = new this.collection(req.body);
            doc.validate()
                .then(()=>{
                    doc.save()
                    .then((data)=>res.status(201).send(data))
                    .catch(err=> next(err));
                })
            .catch(err=>next(err));
        }})

        // Deletes the document. !!! The object you want to delete and which you send to this route HAS TO HAVE
        // THE EXACT SAME PROPERTY NAMES AS THE MODEL IN THE COLLECTION !!!
        routes.push({path: "/", method: ROUTE_METHOD.DELETE, route:(req, res, next)=>{
            let query = req.body;

            this.collection.remove(query)
            .then(()=>res.status(204).send())
            .catch(err=> next(err));
        }})

        routes.push({path: "/add", method: ROUTE_METHOD.POST, route:(req, res, next)=>{
            let body = req.body;
            let arr = []
            arr.push()
            this.collection.findOne({userId: body.userId, date: body.date})
                           .then(document => {
                               let tmp = document['actions']
                               document['actions'] = []
                               tmp = tmp.concat(body.actions)
                               document['actions'] = tmp
                               document.save().then(val => {
                                res.status(202).send(val);
                               }).catch(err => {
                                err.status = 400;
                                next(err);
                               })
                            }).catch(err =>{
                                err.status = 500;
                                next(err);
                            })
        }})

        //Am

        //Put by specific property
        routes.push({path:"/filter/:propertyName/:value", method: ROUTE_METHOD.PUT, route: (req, res, next)=>{
            console.log('in put2');
            console.log(req.params.propertyName);
            console.log(req.params.value);

            let query:any = {};
            query[req.params.propertyName] = req.params.value;
            let body = req.body;

            let id: string;
            let doc:{} = {};
            console.log(body);
            for(let prop in body){
                if(prop === "_id"){
                    id = body[prop];
                } else {
                    doc[prop] = body[prop];
                    
                }
            }
            console.log(doc); //am
            this.collection.findOne(query)
            .then(documenttt=> {

                console.log("was found"); //am

                for(let prop in doc){
                    documenttt[prop] = doc[prop];
                }
                
                documenttt.save().then(val => {
                    res.status(202).send(val);
                }).catch(err => {
                    err.status = 400;
                    next(err);
                });
            
            })
            .catch(err=>next(err));
        }});

        //Am Until here

        // Updates the document. !!! The object you want to update and which you send to this route HAS TO HAVE
        // THE EXACT SAME PROPERTY NAMES AS THE MODEL IN THE COLLECTION !!!
        routes.push({path:"/", method: ROUTE_METHOD.PUT, route:(req, res, next)=>{
            console.log("in put 1")
            let body = req.body;
            console.log("body:")
            console.log(body)

            let id: string;
            let doc:{} = {};

            for(let prop in body){
                if(prop === "_id"){
                    id = body[prop];
                } else {
                    doc[prop] = body[prop];
                }
            }
            console.log("doc:")
            console.log(doc)
           // console.log("doc: \n" + document)

            this.collection.findById(id).then(document => {
                console.log("was found!")
                console.log("document before:")
                console.log(document)
                console.log("doc:")
                console.log(doc)
                for(let prop in doc){
                    document[prop] = doc[prop];
                }
                console.log("document after:")
                console.log(document)
               // console.log("after doc: \n" + document)
                document.save().then(val => {
                    res.status(202).send(val);
                }).catch(err => {
                    console.log("unable to save")
                    err.status = 400;
                    next(err);
                });
            }).catch(err =>{
                console.log("unable to find")
                err.status = 500;
                next(err);
            })
        }})

        for(let specialRoute of specialRoutes){
            routes.push(specialRoute);
        }

        this.BuildRouter(routes);
    }

    private BuildRouter(routes:Array<IRoute>){
        for(let route of routes){
            switch(route.method){
                case ROUTE_METHOD.GET:
                    this._router.get(route.path, route.route);
                    break;
                case ROUTE_METHOD.POST:
                    this._router.post(route.path, route.route);
                    break;
                case ROUTE_METHOD.DELETE:
                    this._router.delete(route.path, route.route);
                    break;
                case ROUTE_METHOD.PUT:
                    this._router.put(route.path, route.route);
                    break;
            }
        }
    }
}
export enum ROUTE_METHOD{
    POST,
    GET,
    PUT,
    DELETE
}
export interface IRoute{
    path:string;
    route: (req : Request, res: Response, next: NextFunction)=>void;
    method: ROUTE_METHOD;
}