"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const boat_1 = require("../Models/boat");
class BoatRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new BoatRouter(boat_1.BoatModel, { path: "/test", method: ApiRouter_1.ROUTE_METHOD.GET, route: (req, res, next) => {
                    res.send("Okay");
                } });
        }
        return this._self.router;
    }
}
exports.BoatRouter = BoatRouter;
//# sourceMappingURL=BoatRouter.js.map