"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const pool_1 = require("../Models/pool");
class PoolRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new PoolRouter(pool_1.PoolModel);
        }
        return this._self.router;
    }
}
exports.PoolRouter = PoolRouter;
//# sourceMappingURL=PoolRouter.js.map