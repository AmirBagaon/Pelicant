"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const User_1 = require("../Models/User");
class UserRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new UserRouter(User_1.UserModel);
        }
        return this._self.router;
    }
}
exports.UserRouter = UserRouter;
//# sourceMappingURL=UserRouter.js.map