import { ApiRouterBase, ROUTE_METHOD, IRoute } from "./ApiRouter";
import { Model, Document } from "mongoose";
import { HitIdModel } from "../Models/HITId";

export class HitRouter extends ApiRouterBase{

    private constructor(collection: Model<Document>, ...specialRoutes:Array<IRoute>){
        super(collection, ...specialRoutes);
    }

    public static get Router(){
        if(!this._self){
            this._self = new HitRouter(HitIdModel);
        }

        return this._self.router;
    }
}