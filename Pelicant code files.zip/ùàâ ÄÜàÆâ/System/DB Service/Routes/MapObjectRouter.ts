import { ApiRouterBase, ROUTE_METHOD, IRoute } from "./ApiRouter";
import {Model, Document} from "mongoose";
import {MapObjectModel} from "../Models/mapObject";

export class MapObjectRouter extends ApiRouterBase{

    private constructor(collection: Model<Document>, ...specialRoutes:Array<IRoute>){
        super(collection, ...specialRoutes);
    }

    public static get Router(){
        if(!this._self){
            this._self = new MapObjectRouter(MapObjectModel);
        }

        return this._self.router;
    }
}