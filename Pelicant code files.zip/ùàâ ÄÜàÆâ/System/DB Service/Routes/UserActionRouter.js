"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const UserAction_1 = require("../Models/UserAction");
class UserActionRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new UserActionRouter(UserAction_1.UserActionModel);
        }
        return this._self.router;
    }
}
exports.UserActionRouter = UserActionRouter;
//# sourceMappingURL=UserActionRouter.js.map