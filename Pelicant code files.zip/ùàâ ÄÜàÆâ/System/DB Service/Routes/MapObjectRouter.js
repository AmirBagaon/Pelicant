"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const mapObject_1 = require("../Models/mapObject");
class MapObjectRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new MapObjectRouter(mapObject_1.MapObjectModel);
        }
        return this._self.router;
    }
}
exports.MapObjectRouter = MapObjectRouter;
//# sourceMappingURL=MapObjectRouter.js.map