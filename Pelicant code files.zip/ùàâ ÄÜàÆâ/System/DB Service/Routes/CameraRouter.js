"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ApiRouter_1 = require("./ApiRouter");
const camera_1 = require("../Models/camera");
class CameraRouter extends ApiRouter_1.ApiRouterBase {
    constructor(collection, ...specialRoutes) {
        super(collection, ...specialRoutes);
    }
    static get Router() {
        if (!this._self) {
            this._self = new CameraRouter(camera_1.CameraModel);
        }
        return this._self.router;
    }
}
exports.CameraRouter = CameraRouter;
//# sourceMappingURL=CameraRouter.js.map