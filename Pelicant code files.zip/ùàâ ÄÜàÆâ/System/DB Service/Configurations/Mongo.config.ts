let configuration = {
    db:{
        connectionString: "killthosebirds-shard-00-00-kwd9h.mongodb.net:27017,killthosebirds-shard-00-01-kwd9h.mongodb.net:27017,killthosebirds-shard-00-02-kwd9h.mongodb.net:27017/test?ssl=true&replicaSet=killthosebirds-shard-0&authSource=admin",
        password:"12345",
        userName: "killthosebirds"
    }
}
export default configuration;