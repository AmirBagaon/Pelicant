"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let configuration = {
    db: {
        connectionString: "killthosebirds-shard-00-00-kwd9h.mongodb.net:27017,killthosebirds-shard-00-01-kwd9h.mongodb.net:27017,killthosebirds-shard-00-02-kwd9h.mongodb.net:27017/test?ssl=true&replicaSet=killthosebirds-shard-0&authSource=admin",
        password: "12345",
        userName: "killthosebirds"
    }
};
exports.default = configuration;
//# sourceMappingURL=Mongo.config.js.map