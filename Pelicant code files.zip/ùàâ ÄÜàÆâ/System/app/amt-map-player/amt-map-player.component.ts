import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs/Rx';
import { MatSnackBar } from '@angular/material';
import * as L from 'leaflet';
import * as turf from 'turf';
import booleanContains from '@turf/boolean-contains';
import shortestPath from '@turf/shortest-path';
import bezierSpline from '@turf/bezier-spline';
import inside from '@turf/inside';
import { Polyline } from 'leaflet';
import { IObstacle } from '../managment/pool-information/pool-information.component';
import { UserManagerService, IUserActions } from '../managment/user-list/user-manager.service';
import { MapPlayerComponent } from '../map-player/map-player.component';

interface ICurrentMarkers {
  markers: L.Marker[];
  numberOfVanished: number;
}

const currentBirds: ICurrentMarkers = {
  markers: [],
  numberOfVanished: 0
};

const animationSpeed = 0.000075;

@Component({
  selector: 'app-amt-map-player',
  templateUrl: './amt-map-player.component.html',
  styleUrls: ['./amt-map-player.component.scss']
})
export class AmtMapPlayerComponent extends MapPlayerComponent {

  currentBirdsToShow: ICurrentMarkers;
  constructor(userService: UserManagerService, public snackBar: MatSnackBar) {
    super(userService, snackBar);
    this.boatLocation = new L.LatLng(32.6374953832361, 35.209636939689524);
    this.currentBirdsToShow = currentBirds;
  }

}
