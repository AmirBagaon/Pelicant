import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmtMapPlayerComponent } from './amt-map-player.component';

describe('AmtMapPlayerComponent', () => {
  let component: AmtMapPlayerComponent;
  let fixture: ComponentFixture<AmtMapPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmtMapPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmtMapPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
