import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DeviceManagerService } from '../../managment/device-list/device-manager.service';
import { IDeviceInformation } from '../../managment/device-information/device-information.component';
import { PoolManagerService } from '../../managment/pool-list/pool-manager.service';
import { IPoolInfo } from '../../managment/pool-information/pool-information.component';

export interface IDevicesByPool {
  devices: string[];
  poolId: string;
}

@Component({
  selector: 'app-video-list',
  templateUrl: './video-list.component.html',
  styleUrls: ['./video-list.component.scss']
})
export class VideoListComponent implements OnInit {

  pools: string[];
  camsByPools: IDevicesByPool[];
  @Input() currentPool: string;
  @Output('editPool') editPool = new EventEmitter<string>();
  constructor(private deviceService: DeviceManagerService,
              private poolService: PoolManagerService) { }


  getPoolList() {
    // service that gets all the pool name
    this.poolService.getPools().subscribe(
      (data: IPoolInfo[]) => {
        this.pools = data.map(pool => pool.poolId);
        for (let i = 0; i < this.pools.length; i++) {
          this.getCamsByPool(this.pools[i], i);
        }
      }
    );
  }

  getCamsByPool(pool: string, i: number) {
    this.deviceService.getDevicesByPool('camera', pool).subscribe(
      (data: IDeviceInformation[]) => {
        this.camsByPools.push({poolId: pool, devices: data.map(dev => dev.ip)});
        if (i === this.pools.length - 1) {
          this.camsByPools.sort((a, b) => a.poolId.localeCompare(b.poolId));
        }
      },
      err => {

      });
  }

  changePool(pool: string) {
    if (this.currentPool !== pool) {
      this.currentPool = pool;
      this.editPool.emit(pool);
    }
  }

  ngOnInit() {
    this.camsByPools = [];
    this.getPoolList();
  }

}
