import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-video-screen',
  templateUrl: './video-screen.component.html',
  styleUrls: ['./video-screen.component.scss']
})
export class VideoScreenComponent implements OnInit {

  @Input() cameraIP: string;
  @Input() isAlive: boolean;
  @Input() poolName: string;
  @Input() cameraID: string;

  constructor() { }

  ngOnInit() {
  }

}
