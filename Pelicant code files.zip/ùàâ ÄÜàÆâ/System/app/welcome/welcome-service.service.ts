import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class WelcomeService{

  constructor() { }

}
