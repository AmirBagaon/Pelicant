import { Component, OnInit } from '@angular/core';
import {Popup} from 'ng2-opd-popup';
import { WelcomeService } from './welcome-service.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {

  constructor(private popup:Popup) { }
  email:string;
  password:string;
  welService:WelcomeService;
  isAdmin:Boolean;
  ngOnInit() {
    this.isAdmin = false;
  }
  showSample(){
    this.isAdmin = false;
    this.popup.options = {
            cancleBtnClass: "btn btn-default", 
            confirmBtnClass: "btn btn-success",
            color: "#A0DE4F",
            header: "Login",
            widthProsentage:30,
            animation: "bounceInDown",
            cancleBtnContent: "Cancel",
            confirmBtnContent: "Login"}
    this.popup.show(this.popup.options);
  }
  adminLogin(){
    this.isAdmin = true;
    this.popup.options = {
            cancleBtnClass: "btn btn-default", 
            confirmBtnClass: "btn btn-danger",
            color: "#FF0000",
            header: "Admin Login",
            widthProsentage:30,
            animation: "bounceInDown",
            cancleBtnContent: "Cancel",
            confirmBtnContent: "Log as Admin"}
    this.popup.show(this.popup.options);
  }

  login(){
    if (this.isAdmin)
    {
      if((this.email.toLowerCase() == "admin") && this.password == "12345")
      {
        alert('Welcome Admin!');
        this.popup.hide();
        window.location.href = "/management";
        
      }
      else
      alert('Fail to log in. Please try again');
    }
    else{
      alert('Email: ' + this.email + '  Password: ' + this.password);
      this.popup.hide();
    }  
  }


}
