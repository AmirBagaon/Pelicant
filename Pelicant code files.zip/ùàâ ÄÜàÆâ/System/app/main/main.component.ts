import { Component, OnInit, Input, ChangeDetectorRef} from '@angular/core';
import { IPoolInfo, IMapObject } from '../managment/pool-information/pool-information.component';
import { PoolManagerService } from '../managment/pool-list/pool-manager.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

  @Input() currentPool: IPoolInfo;
  obstacles: IMapObject[];
  pools: IPoolInfo[];

  //Am
  boatDestination: string;


  constructor(private poolService: PoolManagerService,
              private cdRef: ChangeDetectorRef) { }

  getObstacles(poolId: string) {
    this.poolService.getObstaclesByPool(poolId).subscribe(
      (obstacles: IMapObject[]) => {
        this.obstacles = obstacles;
      }
    );
  }

  destChanged($event) {
    this.boatDestination = $event;
  }

  changePool(poolId: string) {
    for (let i = 0; i < this.pools.length; i++) {
      if (this.pools[i].poolId === poolId) {
        this.currentPool = null;
        this.obstacles = null;
        this.cdRef.detectChanges();
        this.currentPool = this.pools[i];
        this.getObstacles(this.currentPool.poolId);
        break;
      }
    }
  }

  ngOnInit() {
   // this.boatDestination = "stop"; //Am
    this.poolService.getPools().subscribe(
      (pools: IPoolInfo[]) => {
        this.pools = pools;
        
        if (!this.currentPool) {
          //Am
          console.log(this.pools[0])
          console.log("current was null")
          this.currentPool = this.pools[0];
        }
        this.getObstacles(this.currentPool.poolId);
      }
    );
  }

}
