import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoatStatusComponent } from './boat-status.component';

describe('BoatStatusComponent', () => {
  let component: BoatStatusComponent;
  let fixture: ComponentFixture<BoatStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoatStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoatStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
