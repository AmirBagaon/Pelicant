import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DeviceManagerService } from '../managment/device-list/device-manager.service';
import { IDeviceInformation } from '../managment/device-information/device-information.component';
//import { PoolManagerService } from '../managment/pool-list/pool-manager.service';
//import { IPoolInfo } from '../managment/pool-information/pool-information.component';
import { BoatService } from './boat.service';
import { isBuffer } from 'util';
import { ActivatedRoute } from '@angular/router';



// export interface IDevicesByPool {
//   devices: string[];
//   poolId: string;
// }
export interface IBoat {
  _id: string;
  //abc: string;
  ip: string;
  poolId: string;
  locationX: string;
  locationY: string;
  destination: string;
}

export interface ITemp {
  strTemp: string;
  ip: string;
}
export interface Iuser {
  _id: string;
  userName: string;
  email: string;
  rank: string;
  pools: string[];
  passweord: string;
}

@Component({
  selector: 'app-boat-status',
  templateUrl: './boat-status.component.html',
  styleUrls: ['./boat-status.component.scss']
})
export class BoatStatusComponent implements OnInit {

  // Propery 'text' example
  fromSite: object;
  text = ["hi", "bye", "dry"];
  currentBoat: IBoat;
  temp : ITemp;
  userNew: Iuser;
  newBoat: IBoat;
  allBoats: IBoat[];
 boatLocation : String;

 private _destInfo: string;
 
 constructor(private boatService: BoatService,
   //try
   private route: ActivatedRoute
  
  ){
    this.fromSite = {a: "aaa"}
    this.userNew = {_id: "5be157d8d13df818b0c12d80", userName: "tester5", passweord: "blabla", email: "tester@gmail.com", rank: "expert", pools: ["myPool"]};
    this.newBoat = {_id: "5bc788669f9ea921807d25b0", ip: "4.4.4.8", poolId: "myPool", locationX: "2", locationY: "8", destination: "28.2, 24.5"};
    this.boatLocation ='[2,3]';
  this.boatService.getBoats().subscribe(
    (data: IBoat[]) => {
      this.allBoats = data;
    }
  );
  this.boatService.getTemp().subscribe(
    (data: ITemp) => {
      this.temp = data;
      // this.str = this.temp["ip"];  
    }
  );
  this.getBoatFromServer();
} //End of constructor
  ngOnInit() {
    console.log(this.destInfo); //Am
  }


  private getBoatFromServer() {
    this.boatService.getBoatBy_ip("4.4.4.8").subscribe(
      (data: IBoat) => {
        this.currentBoat = data[0];
        // this.str = this.temp["ip"];  
      }
    );
  }

    editIT() {
    //this.boatService.editUser(this.userNew).subscribe();    //worked!
    //this.boatService.editUserbyName("tester5", this.userNew).subscribe(); //worked!
    //this.boatService.editBoat(this.newBoat).subscribe();    //worked!
    this.boatService.changeDestination("myPool", {destination: "100, 100"}).subscribe(); //worked!
  }
  @Input() set destInfo(value: string) {
    this._destInfo = value;
    if(this.currentBoat) {
      this.boatService.changeDestination(this.currentBoat.poolId, {destination: value}).subscribe(); //worked!
      this.currentBoat.destination = value;

      //new try in 28.11
      if (value != "") {
        console.log("TARGET:")
        var splitted = value.split(" ", 3);
        let lat = splitted[0]
        let lng = splitted[2]
         //Tell MP to go there
        this.boatService.getMp(lat, lng).subscribe(
          (data: object) => {            
            console.log(data)
            // this.fromSite = data;
          }
        );
      }
      
      
      


      //In case we want to retrive the info from SERVER and not from component
/*
      this.getBoatFromServer(); 
      //If server didn't updated it immediatly
      setTimeout(() => {
        console.log("in interval");   
        this.getBoatFromServer();
    }, 100);
    */
    }
//    this.currentBoat.destination = value;
  } 

  get destInfo() : string {
    return this._destInfo;
  }
  getIT() {
    this.boatService.getBoatBy_ip("4.4.4.8").subscribe(
      (data: IBoat) => {
        this.currentBoat = data[0];
        // this.str = this.temp["ip"];  
      }
    );
  }
  stamClick() {
    this.boatService.sayHi().subscribe(
      (data: object) => {
        
        console.log(data)
        this.fromSite = data;
      }
    );
  }

  siteClick() {
    console.log("Hi")
    // this.fromSite = "clicked"
    this.boatService.getMPLocation("aaa", "bbb").subscribe(
      (data: object) => {
        
        console.log(data)
        this.fromSite = data;
        this.boatLocation = data["GPS_RAW_INT"]
        console.log(data["GPS_RAW_INT"]["msg"])
      }
    );
  }
  postClick() {
    console.log("in post")
    this.boatService.postMp();
  }


  // pools: string[];
  // camsByPools: IDevicesByPool[];
  // @Input() currentPool: string;
  // @Output('editPool') editPool = new EventEmitter<string>();
  // constructor(private deviceService: DeviceManagerService,
  //             private poolService: PoolManagerService) { }


  // getPoolList() {
  //   // service that gets all the pool name
  //   this.poolService.getPools().subscribe(
  //     (data: IPoolInfo[]) => {
  //       this.pools = data.map(pool => pool.poolId);
  //       for (let i = 0; i < this.pools.length; i++) {
  //         this.getCamsByPool(this.pools[i], i);
  //       }
  //     }
  //   );
  // }

  // getCamsByPool(pool: string, i: number) {
  //   this.deviceService.getDevicesByPool('camera', pool).subscribe(
  //     (data: IDeviceInformation[]) => {
  //       this.camsByPools.push({poolId: pool, devices: data.map(dev => dev.ip)});
  //       if (i === this.pools.length - 1) {
  //         this.camsByPools.sort((a, b) => a.poolId.localeCompare(b.poolId));
  //       }
  //     },
  //     err => {

  //     });
  // }

  // changePool(pool: string) {
  //   if (this.currentPool !== pool) {
  //     this.currentPool = pool;
  //     this.editPool.emit(pool);
  //   }
  // }

  // ngOnInit() {
  //   this.camsByPools = [];
  //   this.getPoolList();
  // }


}
