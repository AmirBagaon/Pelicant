import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { dbServiceIp } from '../app.component';
import { Observable } from 'rxjs/Observable';
//import { IPoolInfo, IMapObject } from '../managment/pool-information/pool-information.component';
import { DeviceManagerService } from '../managment/device-list/device-manager.service';
import * as L from 'leaflet';
import { IBoat, ITemp, Iuser} from './boat-status.component';

@Injectable()
export class BoatService {

   mpURL: string
   targetURL: string;
   usersURL: string;
   locationURL: string;
  constructor(private http: HttpClient,
              private deviceService: DeviceManagerService) {
    this.targetURL = dbServiceIp + '/boat/';
    this.usersURL = dbServiceIp + '/user/';
    this.mpURL = "http://localhost:56781/pelicant/";
    this.locationURL = "http://localhost:56781/pelicant/"
    //  this.targetURL = dbServiceIp + '/boat/';
  }

  getMp(lat: string, lng: string): Observable<object> {
    let newTarget = this.mpURL + lat + '?' + lng + '&'
    console.log("Site url: " + newTarget)
    // console.log(newTarget)
    return this.http.get(newTarget);
  }

  getMPLocation(lat: string, lng: string): Observable<object> {
    return this.http.get(this.locationURL);
  }
  
  postMp() {
    console.log("In post!");
    // return this.http.post(this.mpURL, {
    //       poolId: "pool_name",
    //       bounds: "pool_bounds"
    //     }).subscribe(res => {
    //       console.log(res);
    //     }, err => {
    //       console.log(err);
    //     });

    let headers = new HttpHeaders({
      'Access-Control-Allow-Origin' :'*',
      'Access-Control-Allow-Headers' : 'content-type',
      'Content-Type': 'application/json',
      });
  let options = { headers: headers };
  console.log("options")
  console.log(options)

  // return this.http.post(this.mpURL, null, options);
  return this.http.post(this.mpURL, "amiramir", options).subscribe(res => {
          console.log(res);
        }, err => {
          console.log(err);
        });




    }
  getBoats(): Observable<IBoat[]> {
    return this.http.get<IBoat[]>(this.targetURL);
  }
  sayHi() {
    return this.http.get('http://127.0.0.1:5002/employees/1')
    // .subscribe(data => {
    //   this.serverData = data as JSON;
    //   console.log(this.serverData);
    // })
  }

  getTemp(): Observable<ITemp> {
    return this.http.get<ITemp>(this.usersURL);;
  }
  // getDevicesByPool(device: string, pool: string): Observable<ITemp> {
  //   return this.http.get<ITemp>(dbServiceIp + '/' + device + '/filter/poolId/' + pool);
  // }
  getBoatBy_ip(ip: string) {
    return this.http.get<IBoat>(this.targetURL + 'filter/ip/' + ip);
  }

  editUser(user: Iuser) {
    return this.http.put(this.usersURL, user);
  }
  editUserbyName(userName: string, user: Iuser) {
    return this.http.put((this.usersURL + 'filter/userName/' + userName), user);
  }
  editBoat(boat: IBoat) {
    return this.http.put(this.targetURL, boat);
  }

  changeDestination(poolName: string, destination: object) {
    return this.http.put((this.targetURL + 'filter/poolId/' + poolName), destination);
  }


  //Wasn't tested, and need to make sure every property is in its model schema, in DB
  //Change any element. for example, for change rank of a user named "tester5":
  //  url = userURL, property = userName, propValue = "tester5", info = {rank: "blabla" (and can be added more)}
  changeAnyElement(url: string, property: string, propValue: string, info: object) {
    return this.http.put((url + 'filter/' + property + '/' + propValue), info);
  }



  // changeDestination() {
  //   this.http.post(dbServiceIp + '/destination/', {
  //     destination: "99,99"
  //   }).subscribe(res => {
  //     console.log(res);
  //   }, err => {
  //     console.log(err);
  //   });
  // }/



//const boatUrl = "http://localhost:3001/"



  /*
  getBoatLocation() {
    return this.http.get(boatUrl + '/boatLocation/').subscribe(
      res => {
        res.body
      },
      err => {

    });
  }
  */

  // addPoolTotal (pool_name: string, pool_bounds: L.LatLng[],
  //          obstacles: L.LatLng[][], boats: string[], cams: string[]) {
  //   for (let i = 0; i < boats.length; i++) {
  //     this.deviceService.addDeviceToPool('boat', boats[i], pool_name);
  //   }
  //   for (let i = 0; i < cams.length; i++) {
  //     this.deviceService.addDeviceToPool('camera', cams[i], pool_name);
  //   }
  //   this.addObstacles(pool_name, obstacles);
  //   return this.addPool(pool_name, pool_bounds);
  // }

  // private addPool (pool_name: string, pool_bounds: L.LatLng[]) {
  //   return this.http.post(this.targetURL, {
  //     poolId: pool_name,
  //     bounds: pool_bounds
  //   });
  // }

  // private addObstacles(pool_name: string, obstacles: L.LatLng[][]) {
  //   for (let i = 0; i < obstacles.length; i++) {
  //       this.addObstacle(pool_name, obstacles[i]);
  //   }
  // }

  // public addObstacle(pool_name: string, obstacle: L.LatLng[]) {
  //   this.http.post(dbServiceIp + '/mapObject/', {
  //     poolId: pool_name,
  //     polygon: obstacle,
  //     type: 'obstacle'
  //   }).subscribe(res => {
  //     console.log(res);
  //   }, err => {
  //     console.log(err);
  //   });
  // }

  // getObstaclesByPool(pool_name: string): Observable<IMapObject[]> {
  //   return this.http.get<IMapObject[]>(dbServiceIp + '/mapObject/' + 'filter/poolId/' + pool_name);
  // }

  // setObstacle(obs_id: string, polygon: L.LatLng[]) {
  //   this.http.put(dbServiceIp + '/mapObject/', {
  //     _id: obs_id,
  //     polygon: polygon
  //   }).subscribe(res => {
  //     console.log(res);
  //   }, err => {
  //     console.log(err);
  //   });
  // }

  // removeObstacle(id: string) {
  //   this.http.request('delete', dbServiceIp + '/mapObject/', {
  //     body: {
  //       _id: id
  //     }
  //   }).subscribe(
  //     res => {
  //       console.log(res);
  //     }, err => {
  //       console.log(err);
  //   });
  // }
  // removePool(_id: string) {
  //   this.http.request('delete', this.targetURL, {
  //     body: {
  //       _id: _id
  //     }
  //   }).subscribe(
  //     res => {
  //       console.log(res);
  //     }, err => {
  //       console.log(err);
  //   });
  // }

  

  // getPool(id: string): Observable<IPoolInfo[]> {
  //   return this.http.get<IPoolInfo[]>(this.targetURL + 'filter/poolId/' + id);
  // }

  // getPoolBy_id(id: string) {
  //   return this.http.get<IPoolInfo[]>(this.targetURL + 'filter/_id/' + id);
  // }

  // setPool(id: string, bounds: L.LatLng[]) {
  //   this.http.put(this.targetURL, {
  //     _id: id,
  //     bounds: bounds
  //   }).subscribe(res => {
  //     console.log(res);
  //   }, err => {
  //     console.log(err);
  //   });
  // }

}

