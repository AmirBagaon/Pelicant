import { Component, OnInit, Input } from '@angular/core';
import * as L from 'leaflet';
import { PoolManagerService } from '../pool-list/pool-manager.service';
import { polygon } from 'leaflet';

export interface IPoolInfo {
  _id: string;
  poolId: string;
  bounds: L.LatLng[];
}

export interface IMapObject {
  poolId: string;
  polygon: L.LatLng[];
  type: string;
  _id: string;
}

export interface IObstacle {
  _id: string;
  polygon: L.LatLng[];
}

@Component({
  selector: 'app-pool-information',
  templateUrl: './pool-information.component.html',
  styleUrls: ['./pool-information.component.css']
})
export class PoolInformationComponent implements OnInit {

  @Input() pool: IPoolInfo;
  @Input() boatOpenState: boolean;
  @Input() camOpenState: boolean;

  ready: boolean;
  obstacles: IObstacle[];
  constructor(private poolService: PoolManagerService) {
    this.ready = false;
  }

  getObstacles(pool: string) {
    this.poolService.getObstaclesByPool(pool).subscribe(
      data => {
        this.obstacles = data.map(obstacle => {
          return {
            polygon: obstacle.polygon,
            _id: obstacle._id
          };
        });
        this.ready = true;
      }
    );
  }

  removeObstacle(id: string) {
    this.poolService.removeObstacle(id);
  }

  setObstacle(obstacle: IObstacle) {
    this.poolService.setObstacle(obstacle._id, obstacle.polygon);
  }

  addObstacle(poly: L.LatLng[]) {
    this.poolService.addObstacle(this.pool.poolId, poly);
  }

  setPool(bounds: L.LatLng[]) {
    this.poolService.setPool(this.pool._id, bounds);
  }

  ngOnInit() {
    this.getObstacles(this.pool.poolId);
  }

}
