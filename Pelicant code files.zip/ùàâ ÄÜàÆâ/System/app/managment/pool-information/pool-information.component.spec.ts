import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoolInformationComponent } from './pool-information.component';

describe('PoolInformationComponent', () => {
  let component: PoolInformationComponent;
  let fixture: ComponentFixture<PoolInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoolInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoolInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
