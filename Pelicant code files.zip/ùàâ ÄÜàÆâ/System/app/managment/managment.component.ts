import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managment',
  templateUrl: './managment.component.html',
  styleUrls: ['./managment.component.css']
})
export class ManagmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
