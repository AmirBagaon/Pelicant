import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';

import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { PoolManagerService } from '../pool-list/pool-manager.service';

export interface Iuser {
  userName: string;
  email: string;
  rank: string;
  pools: string[];
}

@Component({
  selector: 'app-user-information',
  templateUrl: './user-information.component.html',
  styleUrls: ['./user-information.component.scss']
})
export class UserInformationComponent implements OnInit {

  @Input() user: Iuser;
  poolCtrl: FormControl;
  filteredPools: Observable<any[]>;
  pools: string[];
  delPool: string;
  answer: boolean;

  constructor(public dialog: MatDialog,
              private _formBuilder: FormBuilder,
              private poolService: PoolManagerService,
              public snackBar: MatSnackBar) {
    this.poolCtrl = new FormControl();
  }

  filterStates(name: string) {
    return this.pools.filter(pool =>
      pool.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  addAuthorisedPool(): void {
    const poolToAdd: string = this.poolCtrl.value;
    if (this.pools.indexOf(poolToAdd) !== -1) {
      if (this.user.pools.indexOf(poolToAdd) === -1) {
        this.user.pools.push(poolToAdd);
        // service to add pool

        this.snackBar.open('the pool ' + poolToAdd, 'has been added to autorised pool list', {
          duration: 2000
        });
      }
    }
  }

  openDialog(pool: string): void {
    this.delPool = pool;
    this.answer = false;
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { delete_item: this.delPool, answer: this.answer }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.answer = result;
      this.removeAuthorisedPool(pool);
    });
  }

  removeAuthorisedPool(pool: string): void {
    if (this.answer) {
      this.user.pools.splice(this.user.pools.indexOf(pool), 1);
      // a service that delete pool from the user autorised pools

      this.snackBar.open('the pool ' + pool, 'has been removed from autorised pool list', {
        duration: 2000
      });
    }
  }

  getPools() {
    this.poolService.getPools().subscribe(
      data => {
        this.pools = data.map(pool => pool.poolId);
        this.pools.push('All');
        this.filteredPools = this.poolCtrl.valueChanges
            .pipe(
              startWith(''),
              map(pool => pool ? this.filterStates(pool) : this.pools.slice())
            );
      }
    );
  }

  ngOnInit() {
    // service that gets the list of all the pools
    this.getPools();
    // this.pools = ['pool 1', 'pool 2', 'pool 3'];
    // this.pools.push('All');
  }

}
