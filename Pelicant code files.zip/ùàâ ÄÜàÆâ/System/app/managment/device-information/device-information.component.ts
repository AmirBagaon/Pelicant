import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

export interface IDeviceInformation {
  ip: string;
  status: string;
}

@Component({
  selector: 'app-device-information',
  templateUrl: './device-information.component.html',
  styleUrls: ['./device-information.component.css']
})
export class DeviceInformationComponent implements OnInit {

  @Input() icon: string;
  @Input() device: IDeviceInformation;
  @Output('deleteDevice') delete = new EventEmitter<IDeviceInformation>();
  constructor() { }

  ngOnInit() {
  }

  deleteDevice(device: IDeviceInformation) {
    this.delete.emit(device);
  }

}
