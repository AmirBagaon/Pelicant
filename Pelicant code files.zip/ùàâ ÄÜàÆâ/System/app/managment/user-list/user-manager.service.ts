import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';
import { dbServiceIp } from '../../app.component';
import { Observable } from 'rxjs/Observable';
import { Iuser } from '../user-information/user-information.component';

export enum Regret {
  No = 1,
  Before,
  After,
  DontCare
}

export interface IAction {
  time: number;
  latlngs: L.LatLng;
}

export interface IUserActions {
  userId: string;
  pool: string;
  actions: IAction[];
  date: string;
}

export interface IRemoteRoute {
  ScenarioID: number;
  CreationTime: number;
  EndTime: number;
  BoatStartXPosition: number;
  BoatStartYPosition: number;
  BoatEndXPosition: number;
  BoatEndYPosition: number;
  ID: number;
}

export interface IRemoteRoutePoint {
  RouteID: number;
  BoatXPosition: number;
  BoatYPosition: number;
  Visited: number;
  TimeTag: number;
}

export interface IRemotePoint {
  x: number;
  y: number;
  Visited: boolean;
  TimeTag: number;
}

export interface IRemoteAction {
  time: number;
  latlngs: IRemotePoint;
  realTime: number;
  type: number;
  endRoute: boolean;
  regret: Regret;
  id: number;
}

export interface IRemoteUserActions {
  userId: string;
  pool: string;
  actions: IRemoteAction[];
  date: string;
}

export interface IBirdConfig {
  ArrivalTime: number;
  DepartureTime: number;
  X: number;
  Y: number;
  IsChased: number;
}

export interface IBirdTimePoint {
  time: number;
  latlngs: IRemotePoint[];
}

export interface IBirdTimeline {
  actions: IBirdTimePoint[];
}

@Injectable()
export class UserManagerService {

  targetURL: string;
  userActionURL: string;
  constructor(private http: HttpClient) {
    this.targetURL = dbServiceIp + '/user/';
    this.userActionURL = dbServiceIp + '/userAction/';
  }

  getUsers(): Observable<Iuser[]> {
    return this.http.get<Iuser[]>(this.targetURL);
  }

  addUser(user: string, email: string, pools: string[]) {
    return this.http.post(this.targetURL, {
      userName: user,
      email: email,
      pools: pools,
      rank: 'beginner', // the server should maybe do that as default as well as the isAdmin
      //Am
      party: 'barIlan',
      password: 'barIlanos'
    });
  }

  removeUser(email: string) {
    this.http.request('delete', this.targetURL, {
      body: {
        email: email
      }
    }).subscribe(
      res => {
        console.log(res);
      }, err => {
        console.log(err);
    });
  }

  editUser(user: Iuser) {
    return this.http.put(this.targetURL, user);
  }

  addUserActions(userAction: IUserActions) {
    return this.http.post(this.userActionURL, userAction);
  }

  addTospecificUserActions(userAction: IUserActions) {
    return this.http.post(this.userActionURL + 'add/', userAction);
  }

  getUserAction(userId: string) {
    return this.http.get<IUserActions[]>(this.userActionURL + 'filter/userId/' + userId);
  }

  getUsersAction() {
    return this.http.get<IUserActions[]>(this.userActionURL);
  }

  getRemoteRoute(scenarioId: number) {
    return this.http.get<IRemoteRoute[]>('../../../assets/' + scenarioId.toString() + '/routes.json');
  }

  getRemoteRoutes(scenarioId: number) {
    return this.http.get<IRemoteRoutePoint[]>('../../../assets/' + scenarioId.toString() + '/points.json');
  }

  getRemoteBirds(scenarioId: number) {
    return this.http.get<IBirdConfig[]>('../../../assets/' + scenarioId.toString() + '/birds.json');
  }

}
