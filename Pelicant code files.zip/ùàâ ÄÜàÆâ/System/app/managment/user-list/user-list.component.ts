import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { Iuser } from '../user-information/user-information.component';
import { UserManagerService } from './user-manager.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  users: Iuser[];
  delUser: string;
  answer: boolean;
  constructor(public dialog: MatDialog,
              private userService: UserManagerService,
              public snackBar: MatSnackBar) {}

  openDialog(user: Iuser): void {
    this.delUser = user.userName;
    this.answer = false;
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { delete_item: this.delUser, answer: this.answer }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.answer = result;
      this.deleteUser(user);
    });
  }

  getUsers() {
    // service that get all the users
    this.userService.getUsers().subscribe(
      data => {
        this.users = data;
      });
  }

  deleteUser(user: Iuser) {
    if (this.answer) {
      // a service that delete from the db a user from
      this.userService.removeUser(user.email);
      this.snackBar.open('the user ' + user.userName, 'has been removed', {
        duration: 2000
      });
      this.users.splice(this.users.indexOf(user), 1);
    }
  }

  addUser(user: Iuser) {
    // service that add the user using the ctrls values
    this.userService.addUser(user.userName, user.email, user.pools)
                    .subscribe(
                      res => {
                        this.getUsers();
                      },
                      err => {
                        console.log(err);
                      }
                    );
    this.snackBar.open('the user ' + user.userName, 'has been added', {
      duration: 2000
    });
  }

  ngOnInit() {
    this.getUsers();
  }

}
