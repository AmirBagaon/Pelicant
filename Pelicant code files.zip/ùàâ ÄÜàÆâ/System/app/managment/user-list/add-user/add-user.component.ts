import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { MatSnackBar } from '@angular/material';

import { Observable } from 'rxjs/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { UserManagerService } from '../user-manager.service';
import { PoolManagerService } from '../../pool-list/pool-manager.service';
import { Iuser } from '../../user-information/user-information.component';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  poolCtrl: FormControl;
  filteredPools: Observable<any[]>;
  pools: string[];
  authorisedPools: string[];

  @Output('addUser') addUserEvent = new EventEmitter<Iuser>();
  constructor(private _formBuilder: FormBuilder,
              private userService: UserManagerService,
              private poolService: PoolManagerService,
              public snackBar: MatSnackBar) {
    this.poolCtrl = new FormControl();
    this.getPools();
  }

  filterStates(name: string) {
    return this.pools.filter(pool =>
      pool.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  addAuthorisedPool(): void {
    const poolToAdd: string = this.poolCtrl.value;
    if (this.pools.indexOf(poolToAdd) !== -1) {
      if (this.authorisedPools.indexOf(poolToAdd) === -1) {
        this.authorisedPools.push(poolToAdd);
      }
    }
  }

  removeAuthorisedPool(pool: string): void {
    this.authorisedPools.splice(this.authorisedPools.indexOf(pool), 1);
  }

  addUser(stepper: MatStepper): void {
    this.addUserEvent.emit({
      email: this.secondFormGroup.value.secondCtrl,
      userName: this.firstFormGroup.value.firstCtrl,
      pools: this.authorisedPools,
      rank: ''
    });
    this.resetStepper(stepper);
  }

  resetStepper(stepper: MatStepper): void {
    this.ngOnInit();
    stepper.selectedIndex = 0;
  }

  getPools() {
    this.poolService.getPools().subscribe(
      data => {
        this.pools = data.map(pool => pool.poolId);
        this.pools.push('All');
        this.filteredPools = this.poolCtrl.valueChanges
            .pipe(
              startWith(''),
              map(pool => pool ? this.filterStates(pool) : this.pools.slice())
            );
      }
    );
  }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['']
    });
    // this.pools = ['pool 1', 'pool 2', 'pool 3'];
    this.authorisedPools = [];
  }
}
