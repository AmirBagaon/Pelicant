import { Component, OnInit, Input, Inject } from '@angular/core';
import { IDeviceInformation } from '../device-information/device-information.component';
import { MatDialog } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { DeviceManagerService } from './device-manager.service';
import { FormControl} from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['./device-list.component.css']
})
export class DeviceListComponent implements OnInit {

  // the type of the device (camera/boat)
  @Input() device: string;
  // pool id/name
  @Input() pool: string;
  // if the upper acordion is open or close.
  @Input() openState: boolean;

  devices: IDeviceInformation[];
  icon: string;
  delDevice: string;
  answer: boolean;
  ipCtrl: FormControl;

  constructor(public dialog: MatDialog,
              private deviceService: DeviceManagerService,
              public snackBar: MatSnackBar) {
    this.ipCtrl = new FormControl();
  }

  openDialog(device: IDeviceInformation): void {
    this.delDevice = device.ip;
    this.answer = false;
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { delete_item: this.delDevice, answer: this.answer }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.answer = result;
      this.deleteDevice(this.device, device, this.pool);
    });
  }

  getListOfDevicesByPool(pool: string, device: string): void {
    // a service that asks from the db all the devices by pool & type
    this.deviceService.getDevicesByPool(device, pool)
                      .subscribe(data => {
                        this.devices = data;
                      }, (err: HttpErrorResponse) => {
                      });
    // this.devices = [{ip: '97.32.111.195', status: 'ok'}];
  }

  deleteDevice(type: string, device: IDeviceInformation, pool: string) {
    if (this.answer) {
      // a service that delete from the db a device from pool
      this.deviceService.deleteDeviceFromPool(type, device.ip, pool);
      this.devices.splice(this.devices.indexOf(device), 1);
      // add message
      this.snackBar.open('the ' + type + ' ' + device.ip, 'has been removed', {
        duration: 2000
      });
    }
  }

  addDevice(device: string, ip: string, pool: string) {
    // a service that add to the db a device from pool
    this.deviceService.addDeviceToPool(device, ip, pool);
    this.devices.push({ip: ip, status: null});
    // add message
    this.snackBar.open('the ' + device + ' ' + ip, 'has been added', {
      duration: 2000
    });
  }

  ngOnInit() {
    this.getListOfDevicesByPool(this.pool, this.device);
    if (this.device === 'boat') {
      this.icon = 'directions_boat';
    } else {
      this.icon = 'linked_camera';
    }
  }

}
