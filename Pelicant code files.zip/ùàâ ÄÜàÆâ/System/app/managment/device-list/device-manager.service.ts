import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IDeviceInformation } from '../device-information/device-information.component';
import { dbServiceIp } from '../../app.component';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class DeviceManagerService {

  constructor(private http: HttpClient) {}

  getDevicesByPool(device: string, pool: string): Observable<IDeviceInformation[]> {
    return this.http.get<IDeviceInformation[]>(dbServiceIp + '/' + device + '/filter/poolId/' + pool);
  }

  addDeviceToPool(device: string, deviceIp: string, pool: string): void {
    this.http.post(dbServiceIp + '/' + device + '/', {
      ip: deviceIp,
      poolId: pool
    }).subscribe(
      res => {
        console.log(res);
      }, err => {
        console.log(err);
    });
  }

  deleteDeviceFromPool(device: string, ip: string, pool: string): void {
    this.http.request('delete', dbServiceIp + '/' + device + '/', {
      body: {
        ip: ip
      }
    }).subscribe(
      res => {
        console.log(res);
      }, err => {
        console.log(err);
    });
  }

}
