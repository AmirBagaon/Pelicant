import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material';
import { PoolManagerService } from '../pool-manager.service';
import * as L from 'leaflet';
import { IPoolInfo } from '../../pool-information/pool-information.component';

@Component({
  selector: 'app-add-pool',
  templateUrl: './add-pool.component.html',
  styleUrls: ['./add-pool.component.scss']
})
export class AddPoolComponent implements OnInit {

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  devices: string[];
  boatDevices: string[];
  camDevices: string[];
  boatCtrl: FormControl;
  camCtrl: FormControl;
  nameCtrl: FormControl;

  bounds: L.LatLng[];
  map: L.Map;
  obstacles: L.LatLng[][];

  @Output('addPool') addPoolEvent = new EventEmitter<IPoolInfo>();

  constructor(private _formBuilder: FormBuilder,
              private poolService: PoolManagerService) {
    this.boatCtrl = new FormControl();
    this.camCtrl = new FormControl();
    this.nameCtrl = new FormControl();
   }

  addBounds(bounds: L.LatLng[]) {
    this.bounds = bounds;
  }

  addPool(stepper: MatStepper): void {
    // service that add the pool using the ctrls values
    this.poolService.addPoolTotal(this.nameCtrl.value, this.bounds, this.obstacles,
                                  this.boatDevices, this.camDevices)
                    .subscribe(res => {
                      this.addPoolEvent.emit({
                        poolId: this.nameCtrl.value,
                        bounds: this.bounds,
                        _id: null
                      });
                    }, err => {
                      console.log(err);
                    });
    this.resetStepper(stepper);
  }

  resetStepper(stepper: MatStepper): void {
    this.ngOnInit();
    stepper.selectedIndex = 0;
  }

  addDevice(device: string) {
    let deviceToAdd = '';
    if (device === 'boat') {
     deviceToAdd = this.boatCtrl.value;
     if (this.boatDevices.indexOf(deviceToAdd) === -1) {
      this.boatDevices.push(deviceToAdd);
    }
    } else {
      deviceToAdd = this.camCtrl.value;
      if (this.camDevices.indexOf(deviceToAdd) === -1) {
        this.camDevices.push(deviceToAdd);
      }
    }

  }

  addObstacle(obstacle: L.LatLng[]) {
    this.obstacles.push(obstacle);
  }

  removeDevice(type: string, device: string): void {
    if (type === 'boat') {
      this.boatDevices.splice(this.devices.indexOf(device), 1);
    } else {
      this.camDevices.splice(this.devices.indexOf(device), 1);
    }
  }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['']
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['']
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['']
    });

    this.camDevices = [];
    this.boatDevices = [];
    this.obstacles = [];
  }

}
