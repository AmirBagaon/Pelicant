import { TestBed, inject } from '@angular/core/testing';

import { PoolManagerService } from './pool-manager.service';

describe('PoolManagerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PoolManagerService]
    });
  });

  it('should be created', inject([PoolManagerService], (service: PoolManagerService) => {
    expect(service).toBeTruthy();
  }));
});
