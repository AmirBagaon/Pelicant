import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';
import { dbServiceIp } from '../../app.component';
import { Observable } from 'rxjs/Observable';
import { DeviceManagerService } from '../device-list/device-manager.service';
import { IPoolInfo, IMapObject } from '../pool-information/pool-information.component';
import * as L from 'leaflet';

const boatUrl = "http://localhost:3001/"

@Injectable()
export class PoolManagerService {

  targetURL: string;
  constructor(private http: HttpClient,
              private deviceService: DeviceManagerService) {
    this.targetURL = dbServiceIp + '/pool/';
  }

  /*
  getBoatLocation() {
    return this.http.get(boatUrl + '/boatLocation/').subscribe(
      res => {
        res.body
      },
      err => {

    });
  }
  */

  addPoolTotal (pool_name: string, pool_bounds: L.LatLng[],
           obstacles: L.LatLng[][], boats: string[], cams: string[]) {
    for (let i = 0; i < boats.length; i++) {
      this.deviceService.addDeviceToPool('boat', boats[i], pool_name);
    }
    for (let i = 0; i < cams.length; i++) {
      this.deviceService.addDeviceToPool('camera', cams[i], pool_name);
    }
    this.addObstacles(pool_name, obstacles);
    return this.addPool(pool_name, pool_bounds);
  }

  private addPool (pool_name: string, pool_bounds: L.LatLng[]) {
    return this.http.post(this.targetURL, {
      poolId: pool_name,
      bounds: pool_bounds
    });
  }

  private addObstacles(pool_name: string, obstacles: L.LatLng[][]) {
    for (let i = 0; i < obstacles.length; i++) {
        this.addObstacle(pool_name, obstacles[i]);
    }
  }

  public addObstacle(pool_name: string, obstacle: L.LatLng[]) {
    this.http.post(dbServiceIp + '/mapObject/', {
      poolId: pool_name,
      polygon: obstacle,
      type: 'obstacle'
    }).subscribe(res => {
      console.log(res);
    }, err => {
      console.log(err);
    });
  }

  getObstaclesByPool(pool_name: string): Observable<IMapObject[]> {
    return this.http.get<IMapObject[]>(dbServiceIp + '/mapObject/' + 'filter/poolId/' + pool_name);
  }

  setObstacle(obs_id: string, polygon: L.LatLng[]) {
    this.http.put(dbServiceIp + '/mapObject/', {
      _id: obs_id,
      polygon: polygon
    }).subscribe(res => {
      console.log(res);
    }, err => {
      console.log(err);
    });
  }

  removeObstacle(id: string) {
    this.http.request('delete', dbServiceIp + '/mapObject/', {
      body: {
        _id: id
      }
    }).subscribe(
      res => {
        console.log(res);
      }, err => {
        console.log(err);
    });
  }
  removePool(_id: string) {
    this.http.request('delete', this.targetURL, {
      body: {
        _id: _id
      }
    }).subscribe(
      res => {
        console.log(res);
      }, err => {
        console.log(err);
    });
  }

  getPools(): Observable<IPoolInfo[]> {
    return this.http.get<IPoolInfo[]>(this.targetURL);
  }

  getPool(id: string): Observable<IPoolInfo[]> {
    return this.http.get<IPoolInfo[]>(this.targetURL + 'filter/poolId/' + id);
  }

  getPoolBy_id(id: string) {
    return this.http.get<IPoolInfo[]>(this.targetURL + 'filter/_id/' + id);
  }

  setPool(id: string, bounds: L.LatLng[]) {
    this.http.put(this.targetURL, {
      _id: id,
      bounds: bounds
    }).subscribe(res => {
      console.log(res);
    }, err => {
      console.log(err);
    });
  }

}
