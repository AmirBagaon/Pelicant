import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { PoolManagerService } from './pool-manager.service';
import { IPoolInfo } from '../pool-information/pool-information.component';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-pool-list',
  templateUrl: './pool-list.component.html',
  styleUrls: ['./pool-list.component.css']
})
export class PoolListComponent implements OnInit {

  pools: IPoolInfo[];
  delPool: string; //Am
  answer: boolean;
  constructor(private poolService: PoolManagerService,
              public dialog: MatDialog,
              public snackBar: MatSnackBar) { }

  getPoolList() {
    // service that gets all the pool name
    this.poolService.getPools().subscribe(
      (data: IPoolInfo[]) => {
        this.pools = data;
      }
    );
  }

  addPool(pool: IPoolInfo) {
    this.pools.push(pool);
    this.getPoolList();
    this.snackBar.open('the pool ' + pool.poolId, 'has been added', {
      duration: 2000
    });
  }

//Amir Changes
openDialog(pool: IPoolInfo): void {
  this.delPool = pool.poolId;
  this.answer = false;
  const dialogRef = this.dialog.open(DeleteDialogComponent, {
    width: '300px',
    data: { delete_item: this.delPool, answer: this.answer }
  });

  dialogRef.afterClosed().subscribe(result => {
    this.answer = result;
    this.deleteUser(pool);
  });
}
deleteUser(pool: IPoolInfo) {
  if (this.answer) {
    // a service that delete from the db a user from
    this.poolService.removePool (pool._id);
    this.snackBar.open('The pool ' + pool.poolId, 'has been removed', {
      duration: 2000
    });
    this.pools.splice(this.pools.indexOf(pool), 1);
  }
}

  ngOnInit() {
    this.getPoolList();
  }
}



