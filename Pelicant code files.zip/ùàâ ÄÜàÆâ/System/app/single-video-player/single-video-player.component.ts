import { Component, OnInit, Input } from '@angular/core';
import { IMapObject, IPoolInfo } from '../managment/pool-information/pool-information.component';
import { PoolManagerService } from '../managment/pool-list/pool-manager.service';
import { ActivatedRoute } from '@angular/router';
import { IUserActions } from '../managment/user-list/user-manager.service';

@Component({
  selector: 'app-single-video-player',
  templateUrl: './single-video-player.component.html',
  styleUrls: ['./single-video-player.component.scss']
})
export class SingleVideoPlayerComponent implements OnInit {

  currentPool: IPoolInfo;
  date: string;
  workerId: string;
  obstacles: IMapObject[];
  constructor(private poolService: PoolManagerService,
              private route: ActivatedRoute) {
  }

  getObstacles(poolId: string) {
    this.poolService.getObstaclesByPool(poolId).subscribe(
      (obstacles: IMapObject[]) => {
        this.obstacles = obstacles;
      }
    );
  }

  ngOnInit() {
    this.route.queryParams
        .subscribe(params => {
          this.date = params['date'];
          this.workerId = params['workerId'];
          this.poolService.getPoolBy_id(params['poolId']).subscribe(
            (pool: IPoolInfo[]) => {
            this.currentPool = pool[0];
            this.getObstacles(this.currentPool.poolId);
          });
        });
  }
}

