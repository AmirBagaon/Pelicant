import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleVideoPlayerComponent } from './single-video-player.component';

describe('SingleVideoPlayerComponent', () => {
  let component: SingleVideoPlayerComponent;
  let fixture: ComponentFixture<SingleVideoPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleVideoPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleVideoPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
