import { Component, OnInit, ViewChild } from '@angular/core';
import {Popup} from 'ng2-opd-popup';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  email:string;
  password:string;

  constructor(private popup5:Popup) { }
  

  ngOnInit() {
  }

  showPopup5(){
    this.popup5.options = {
            cancleBtnClass: "btn btn-default", 
            confirmBtnClass: "btn btn-mbe-attack",
            color: "#A0DE4F",
            header: "Login...",
            widthProsentage:50,
            animation: "bounceInDown",
            confirmBtnContent: "Login"}
    this.popup5.show(this.popup5.options);
  }


  login(){
    alert('Email: ' + this.email + '  Password: ' + this.password);
    this.popup5.hide();
  }


}
