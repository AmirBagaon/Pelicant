import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as L from 'leaflet';
import { IObstacle } from '../managment/pool-information/pool-information.component';

interface IObstacleCol {
  _id: string;
  color: string;
}

@Component({
  selector: 'app-map-choser',
  templateUrl: './map-choser.component.html',
  styleUrls: ['./map-choser.component.scss']
})
export class MapChoserComponent implements OnInit {

  @Input() center: L.LatLng;
  @Input() bounds: L.LatLng[];
  @Input() obstacels: IObstacle[];
  @Output('addBounds') addBounds = new EventEmitter<L.LatLng[]>();
  @Output('addObstacle') addObstacle = new EventEmitter<L.LatLng[]>();
  @Output('editPool') editPool = new EventEmitter<L.LatLng[]>();
  @Output('editObstacle') editObstacle = new EventEmitter<IObstacle>();
  @Output('removeObstacle') removeObstacle = new EventEmitter<string>();

  options;
  drawOptions;
  // the last layer with point
  lastLayer: L.TileLayer;
  map: L.Map;

  drawnItems;
  selectedbounds: L.LatLng[];

  satelliteMap: L.TileLayer;
  streetmap: L.TileLayer;
  currentProvider: L.TileLayer;
  ourCustomControl: L.Control;
  colors;
  constructor() {
    this.satelliteMap = L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', {
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
    });
    this.streetmap = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
    });

    this.currentProvider = this.streetmap;
  }

  random_rgb(): string {
    const o = Math.round, r = Math.random, s = 255;
    return 'rgb(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ')';
  }

  onMapReady(map: L.Map) {
    this.map = map;

    if (this.bounds) {
      this.fitBoundsByChange(this.bounds);
      const polygon = new L.Polygon(this.bounds);
      polygon.setStyle({fillColor: 'green'});
      polygon.setStyle({color: 'green'});
      polygon.setStyle({fillOpacity: 0.3});
      this.drawnItems.addLayer(polygon);
    }

    // add the obstacles to the map
    if (this.obstacels) {
      for (let i = 0; i < this.obstacels.length; i++) {
        const polygon = L.polygon(this.obstacels[i].polygon);
        const color = this.random_rgb();
        this.colors[color] = this.obstacels[i]._id;
        polygon.setStyle({fillColor: color});
        polygon.setStyle({color: color});
        polygon.setStyle({fillOpacity: 100});
        this.drawnItems.addLayer(polygon);
      }
    }

    this.map.addLayer(this.drawnItems);

    this.map.on(L.Draw.Event.CREATED, (event: any) => {
      const layer = event.layer;
      this.drawnItems.addLayer(layer);
      this.selectedbounds = layer._latlngs;
      this.addBounds.emit(this.selectedbounds);
      this.addObstacle.emit(this.selectedbounds);
    });

    this.map.on(L.Draw.Event.DELETED, (event: any) => {
      const layers = event.layers;
      const colors = this.colors;
      layers.eachLayer( (layer) => {
        const bounds = layer._latlngs;
        if (layer.options.color === 'green') {
          // todo - remove the map bounds ...
        } else {
          this.removeObstacle.emit(colors[layer.options.color]);
        }
      });
    });

    this.map.on(L.Draw.Event.EDITED, (event: any) => {
      const layers = event.layers;
      let bounds = this.selectedbounds;
      const items = this.drawnItems;
      const colors = this.colors;
      layers.eachLayer( (layer) => {
        bounds = layer._latlngs;
        if (layer.options.color === 'green') {
          this.editPool.emit(bounds);
        } else {
          this.editObstacle.emit({
            polygon: bounds,
            _id: colors[layer.options.color]
          });
        }
        items.addLayer(layer);
      });
      this.selectedbounds = bounds;
      this.drawnItems = items;
      this.addBounds.emit(this.selectedbounds);
      this.addObstacle.emit(this.selectedbounds);
    });

    this.map.addEventListener('mousemove', (event: any) => {
      const lat = event.latlng.lat;
      const lng = event.latlng.lng;
      if (this.lastLayer) {
        this.map.removeLayer(this.lastLayer);
      }
      //Am
      //The coordinates in the right bottom corner when mouse move
      const attribution = lat.toString().substring(0, 8) + ' , ' + lng.toString().substring(0, 8);
      this.lastLayer = L.tileLayer('', {
        attribution: attribution
      }).addTo(this.map);
   });

    const changeProviderControl = L.Control.extend({
       options: {
         position: 'topleft',
         // control position - allowed: 'topleft', 'topright', 'bottomleft', 'bottomright'
       },

       onAdd: (map: L.Map) => {
         const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');
         container.style.backgroundColor = 'white';
         container.style.width = '30px';
         container.style.height = '30px';
         container.style.cursor = 'pointer';
         container.style.backgroundImage = 'url(https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Globe_icon_Noun_132351_cc.svg/2000px-Globe_icon_Noun_132351_cc.svg.png)';
         container.style.backgroundSize = '24px 24px';
         container.style.backgroundPosition = 'center';
         container.style.backgroundRepeat = 'no-repeat';
         container.onclick = () => {
           this.changeProvider(map);
         };
         return container;
       },
     });

    this.map.addControl(new changeProviderControl());

  }

  fitBoundsByChange(selectedbounds: L.LatLng[]) {
    const bounds: L.LatLngBounds = L.latLngBounds(selectedbounds);
    this.map.dragging.disable();
    this.map.fitBounds(bounds, {
      padding: L.point(24, 24),
      maxZoom: 22,
      animate: true
    });
    this.map.removeLayer(this.drawnItems);
  }

  changeProvider(map: L.Map) {
    if (this.currentProvider === this.streetmap) {
      map.removeLayer(this.streetmap);
      this.satelliteMap.addTo(map);
      this.currentProvider = this.satelliteMap;
    } else {
      map.removeLayer(this.satelliteMap);
      this.streetmap.addTo(map);
      this.currentProvider = this.streetmap;
    }
  }

  reanderMap() {
    this.map.invalidateSize();
  }

  ngOnInit() {

    this.colors = [];

    this.drawnItems = L.featureGroup();

    this.options = {
      layers: [
        this.streetmap
      ],
      zoom: 22,
      maxNativeZoom: 18,
      // center: this.center ? this.center : L.latLng(32.64716, 35.2488),
      //Am 16/12
      center: this.center ? this.center : L.latLng(32.06672, 34.84174),
      maxBounds: this.bounds
    };

    this.drawOptions = {
      draw: {
        polyline: false,
        marker: false,
        circle: false,
        circlemarker: false,
        polygon: {
            shapeOptions: {
                color: '#D50000'
            }
        }
      },
      edit: {
        featureGroup: this.drawnItems
      }
    };

  }

}
