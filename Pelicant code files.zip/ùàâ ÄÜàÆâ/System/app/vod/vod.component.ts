import { Component, OnInit } from '@angular/core';
import { IMapObject, IPoolInfo } from '../managment/pool-information/pool-information.component';
import { PoolManagerService } from '../managment/pool-list/pool-manager.service';
import { Router } from '@angular/router';
import { UserManagerService, IUserActions } from '../managment/user-list/user-manager.service';

@Component({
  selector: 'app-vod',
  templateUrl: './vod.component.html',
  styleUrls: ['./vod.component.scss']
})
export class VodComponent implements OnInit {

  usersAction: IUserActions[];
  constructor(private userService: UserManagerService,
              private route: Router) {
  }

  openVOD(userAction: IUserActions) {
    let uri = '/video?workerId=' + userAction.userId;
    uri += '&poolId=' + userAction.pool;
    uri += '&date=' + userAction.date;
    this.route.navigateByUrl(uri).then(res => {
      console.log('res');
    });
  }

  ngOnInit() {
    this.usersAction = [];
    this.userService.getUsersAction().subscribe(
      (usersActions: IUserActions[]) => {
        this.usersAction = usersActions;
    });
  }
}
