import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { MatListModule, MatIconModule, MatToolbarModule, MatCheckboxModule,
         MatButtonModule, MatExpansionModule, MatFormFieldModule,
         MatInputModule, MatCardModule, MatStepperModule, MatSnackBarModule,
         MatAutocompleteModule, MatChipsModule, MatDialogModule,
         MatProgressBarModule, MatGridListModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { MatSidenavModule } from '@angular/material/sidenav';
import { AppComponent } from './app.component';
import { ManagmentComponent } from './managment/managment.component';
import { PoolInformationComponent } from './managment/pool-information/pool-information.component';
import { DeviceInformationComponent } from './managment/device-information/device-information.component';
import { DeviceListComponent } from './managment/device-list/device-list.component';
import { PoolListComponent } from './managment/pool-list/pool-list.component';
import { UserListComponent } from './managment/user-list/user-list.component';
import { UserInformationComponent } from './managment/user-information/user-information.component';
import { AddUserComponent } from './managment/user-list/add-user/add-user.component';
import { VideoScreenComponent } from './Video/video-screen/video-screen.component';
import { VideoListComponent } from './Video/video-list/video-list.component';
import { DeleteDialogComponent } from './managment/delete-dialog/delete-dialog.component';

import { LeafletModule } from '@asymmetrik/ngx-leaflet';
import { LeafletDrawModule } from '@asymmetrik/ngx-leaflet-draw';
import { MapChoserComponent } from './map-choser/map-choser.component';
import { MapPlayerComponent } from './map-player/map-player.component';
import { MainComponent } from './main/main.component';
import { AddPoolComponent } from './managment/pool-list/add-pool/add-pool.component';
import { DeviceManagerService } from './managment/device-list/device-manager.service';
import { PoolManagerService } from './managment/pool-list/pool-manager.service';
import { UserManagerService } from './managment/user-list/user-manager.service';
import { AmtExpComponent } from './amt-exp/amt-exp.component';
import { ToolBarComponent } from './tool-bar/tool-bar.component';
import { MapVodComponent } from './map-vod/map-vod.component';
import { VodComponent } from './vod/vod.component';
import { SingleVideoPlayerComponent } from './single-video-player/single-video-player.component';
import { AmtMapPlayerComponent } from './amt-map-player/amt-map-player.component';
import { SubmitDialogComponent } from './amt-exp/submit-dialog/submit-dialog.component';
import { InstructionsDialog1Component } from './amt-exp/instructions-dialog-1/instructions-dialog-1.component';
import { InstructionsDialog2Component } from './amt-exp/instructions-dialog-2/instructions-dialog-2.component';
import { InstructionsDialog3Component } from './amt-exp/instructions-dialog-3/instructions-dialog-3.component';
import { RemoteMapVodComponent } from './remote-map-vod/remote-map-vod.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { WelcomeService } from './welcome/welcome-service.service';
import { BoatStatusComponent } from './boat-status/boat-status.component';
import { BoatService } from './boat-status/boat.service';
import { LoginComponent } from './login/login.component';
import {PopupModule} from 'ng2-opd-popup';

@NgModule({
  declarations: [
    AppComponent,
    ManagmentComponent,
    PoolInformationComponent,
    DeviceInformationComponent,
    DeviceListComponent,
    PoolListComponent,
    UserListComponent,
    UserInformationComponent,
    AddUserComponent,
    VideoScreenComponent,
    VideoListComponent,
    DeleteDialogComponent,
    MapChoserComponent,
    MapPlayerComponent,
    MainComponent,
    AddPoolComponent,
    AmtExpComponent,
    ToolBarComponent,
    MapVodComponent,
    VodComponent,
    SingleVideoPlayerComponent,
    AmtMapPlayerComponent,
    SubmitDialogComponent,
    InstructionsDialog1Component,
    InstructionsDialog2Component,
    InstructionsDialog3Component,
    RemoteMapVodComponent,
    WelcomeComponent,
    BoatStatusComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatIconModule,
    MatToolbarModule,
    MatExpansionModule,
    MatCheckboxModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    MatGridListModule,
    MatButtonModule,
    MatCardModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatDialogModule,
    MatListModule,
    MatProgressBarModule,
    LeafletModule,
    LeafletDrawModule,
    HttpModule,
    FormsModule,
    MatSidenavModule,
    MatSnackBarModule,
    HttpClientModule,
    PopupModule.forRoot(),
    RouterModule.forRoot([
      { path: 'game', component: AmtExpComponent},
      { path: 'video', component: SingleVideoPlayerComponent },
      { path: 'vod', component: VodComponent},
      { path: 'remoteVod', component: RemoteMapVodComponent},
      { path: 'management', component: ManagmentComponent },
      { path: '', component: MainComponent },
      { path: 'welcome', component: WelcomeComponent },
      { path: 'login', component: LoginComponent },
      { path: 'main', component: MainComponent },
      { path: '**', component: MainComponent }
    ])
  ],
  providers: [DeviceManagerService, PoolManagerService, UserManagerService, BoatService],
  bootstrap: [AppComponent],
  entryComponents: [DeleteDialogComponent, SubmitDialogComponent, InstructionsDialog1Component,
    InstructionsDialog2Component, InstructionsDialog3Component]
})
export class AppModule { }
