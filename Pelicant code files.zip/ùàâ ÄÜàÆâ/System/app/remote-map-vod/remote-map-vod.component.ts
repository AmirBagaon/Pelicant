import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as turf from 'turf';
import bezierSpline from '@turf/bezier-spline';
import { IRemoteRoute, IRemoteUserActions, IRemoteAction,
         IRemotePoint, UserManagerService, IRemoteRoutePoint,
         IBirdConfig, IBirdTimeline, IBirdTimePoint, Regret } from '../managment/user-list/user-manager.service';
import { ActivatedRoute } from '@angular/router';




interface IFeatures {
  timeFromLastDesicion: number;
  timeTillNextDesicion: number;
  idelTime: number;
  timeTillPathDone: number;
  backgroundPath: boolean;
  regret: Regret;
}

interface ITimelinePoint {
  time: number;
  latlng: IRemotePoint;
  features: IFeatures;
  endRoute: boolean;
  id: number;
}

interface ITimeLinePointFeatures {
  latlng: IRemotePoint;
  backgroundPath: boolean;
  leftLenPath: number;
  timeFromLastAction: number;
  endRoute: boolean;
}

interface ITimeLinePoint {
  time: number;
  features: ITimeLinePointFeatures;
}

interface ITimeAndIndex {
  time: number;
  index: number;
}

interface ITimeAndScore {
  time: number;
  score: number;
  latlng: IRemotePoint;
  endRoute: boolean;
  id: number;
}

const EXP_TIME = 1212022; // 1200000;
const timeouts = [];
const messageName = 'zero-timeout-message';
const speedPerPointMs = 5;

const data = [{3: 281}, {4: 422}, {7: 190}, {8: 422}, {10: 281}, {11: 281}];

@Component({
  selector: 'app-remote-map-vod',
  templateUrl: './remote-map-vod.component.html',
  styleUrls: ['./remote-map-vod.component.scss']
})
export class RemoteMapVodComponent implements OnInit {

  remoteActions: IRemoteUserActions;
  @ViewChild('myCanvas') canvasRef: ElementRef;
  ctx: CanvasRenderingContext2D;
  boatImage: HTMLImageElement;
  birdImage: HTMLImageElement;
  redBirdImage: HTMLImageElement;
  timeOfShort: number;
  interval: number;
  buffer: number;
  SenarioId: number;
  realTime: string;
  full: boolean;
  add: number;

  constructor(private userService: UserManagerService,
              private route: ActivatedRoute) { }

  bezierPath(points: IRemotePoint[]): IRemotePoint[] {
    const currentPath = [];
    for (let i = 0; i < points.length; i++) {
      currentPath.push([points[i].x, points[i].y]);
    }
    const visited: boolean = points[0].Visited;
    let time = points[1].TimeTag - points[0].TimeTag;
    time = time < 11 ? 11 : time;
    const curved  = bezierSpline(turf.lineString(currentPath), {
                                  resolution: time,
                                  sharpness: 0
                                }).geometry.coordinates;
    const currentPathLatLngs: IRemotePoint[] = [];
    for (let i = 0; i < curved.length; i += 2) {
      currentPathLatLngs.push({ x: curved[i][0], y: curved[i][1],
                                Visited: visited, TimeTag: 1 });
    }
    return currentPathLatLngs;
  }

  getPointsByRouteId(id: number, remoteRoute: IRemoteRoutePoint[]): IRemotePoint[] {
    let remotePoints: IRemotePoint[] = [];
    let flag = false;
    for (let i = 0; i < remoteRoute.length; i++) {
      if (remoteRoute[i].RouteID !== id) {
        if (flag) {
          return remotePoints;
        }
        continue;
      }
      const ps = { x: remoteRoute[i].BoatXPosition,
                   y: remoteRoute[i].BoatYPosition,
                   Visited: remoteRoute[i].Visited === 1,
                   TimeTag: remoteRoute[i].TimeTag };
      if (i + 1 < remoteRoute.length) {
        if (remoteRoute[i + 1].RouteID === id) {
          const pe = { x: remoteRoute[i + 1].BoatXPosition,
                       y: remoteRoute[i + 1].BoatYPosition,
                       Visited: remoteRoute[i + 1].Visited === 1,
                       TimeTag: remoteRoute[i + 1].TimeTag};
          remotePoints = remotePoints.concat(this.bezierPath([ps, pe]));
        }
      } else {
        remotePoints.push(ps);
      }
      flag = true;
    }
    return remotePoints;
  }

  isGoingToRegret(remotePoints: IRemotePoint[]): boolean {
    for (let i = 0; i < remotePoints.length; i++) {
      if (!remotePoints[i].Visited) {
        return true;
      }
    }
    return false;
  }

  getRegretState(goingToRegret: boolean, regretRoute: boolean) {
    if (goingToRegret) {
      return Regret.Before;
    }
    if (regretRoute) {
      return Regret.After;
    }
    return Regret.No;
  }

  getRemoteRoute(id: number, birdsTimeline: IBirdTimeline) {
    let remotePaths: IRemoteRoute[] = [];
    this.remoteActions = {
      actions: [],
      date: Date.now().toString(),
      pool: null,
      userId: 'A1VSXOCH5ILDOR'
    };
    this.userService.getRemoteRoute(id).subscribe(
      (remoteRoute: IRemoteRoute[]) => {
        /*
        for (let i = 0; i < remoteRoute.length; i++) {
          if (id === remoteRoute[i].ScenarioID) {
            remotePaths.push(remoteRoute[i]);
          }
        }
        */
       remotePaths = remoteRoute;
        this.userService.getRemoteRoutes(id).subscribe(
          (remotePointsByRoute: IRemoteRoutePoint[]) => {
            let pointTime = 0;
            let regretRoute = false;
            for (let i = 0; i < remotePaths.length; i++) {
              let remotePoints: IRemotePoint[] = [];
              remotePoints = this.getPointsByRouteId(remotePaths[i].ID, remotePointsByRoute);
              if (!remotePoints || remotePoints.length === 0 || !remotePoints[0].Visited) {
                regretRoute = true;
                continue;
              }
              let timePerPoint = (remotePaths[i].EndTime - remotePaths[i].CreationTime); // * 1000;
              timePerPoint = timePerPoint === 0 ? (speedPerPointMs * remotePoints.length) : timePerPoint;
              timePerPoint = Math.ceil(timePerPoint / remotePoints.length);
              pointTime = remotePaths[i].CreationTime; // * 1000;
              const goingToRegret = this.isGoingToRegret(remotePoints);
              const regret = this.getRegretState(goingToRegret, regretRoute);
              regretRoute = false;
              for (let j = 0; j < remotePoints.length; j++) {
                if (!remotePoints[j].Visited) {
                  console.log(remotePaths[i].ID);
                  regretRoute = true;
                  break;
                }
                const end = j + 1 >= remotePoints.length;
                this.remoteActions.actions.push({latlngs: remotePoints[j],
                                                 time: pointTime,
                                                 realTime: pointTime, type: 0,
                                                 endRoute: end, regret: regret,
                                                 id: remotePaths[i].ID});
                pointTime += timePerPoint;
              }
            }
            console.log(this.remoteActions);
            if (this.full) {
              this.playMapRecord(this.remoteActions, birdsTimeline);
            } else {
              const timeline = this.extractFeatures(this.remoteActions.actions);
              const scoreTimeline = this.scoreByTimeLine(timeline);
              this.remoteActions = this.chooseRandomPoints(scoreTimeline, this.interval, this.buffer);
              console.log(this.remoteActions);
              this.timeOfShort = new Date().getTime();
              this.playShortMapRecord(this.remoteActions, birdsTimeline);
            }
          });
      });
  }

  secondToHumanReadableSTR(seconds: number) {
    const numminutes = Math.floor((((seconds % 31536000) % 86400) % 3600) / 60);
    const numseconds = (((seconds % 31536000) % 86400) % 3600) % 60;
    let numsecondsSTR = '' + numseconds;
    let numminutesSTR = '' + numminutes;
    if (numseconds < 10) {
      numsecondsSTR = '0' + numseconds;
    }
    if (numminutes < 10) {
      numminutesSTR = '0' + numminutes;
    }
    return numminutesSTR + ':' + numsecondsSTR;
  }

  async playShortMapRecord(userAction: IRemoteUserActions, birdsTimeline: IBirdTimeline) {
    let nextTime = 0;
    this.ctx.lineWidth = 3;
    this.ctx.font = '30px Segoe UI';
    for (let i = 0; i < userAction.actions.length; i++) {
      if (i + 1 < userAction.actions.length) {
        nextTime = userAction.actions[i + 1].time - userAction.actions[i].time;
        // nextTime = nextTime >= 300 ? 500 : 4;
        this.ctx.strokeStyle = 'green';
        if (userAction.actions[i + 1].type === 1) {
          this.ctx.strokeStyle = 'red';
        }
      }
      // draw
      this.draw(userAction, i, birdsTimeline, 0, 0, true);
      // sleep
      if (nextTime > 0) {
          await this.sleep(nextTime);
          if (i % 6000 === 0) {
            await this.sleep(500);
          }
        this.ctx.clearRect(0, 0, 1000, 1000);
      }
    }
    const boatLocation = userAction.actions[userAction.actions.length - 1].latlngs;
    this.ctx.drawImage(this.boatImage, boatLocation.x, boatLocation.y, 50, 50);
    console.log('done');
    console.log((new Date().getTime() - this.timeOfShort) / 1000);
  }

  async playMapRecord(userAction: IRemoteUserActions, birdsTimeline: IBirdTimeline) {
    let nextTime = 0;
    this.ctx.lineWidth = 3;
    this.ctx.font = '30px Segoe UI';
    for (let i = 0; i < userAction.actions.length; i++) {
      if (i + 1 < userAction.actions.length) {
        nextTime = userAction.actions[i + 1].time - userAction.actions[i].time;
        this.ctx.strokeStyle = 'green';
        if (userAction.actions[i + 1].type === 1) {
          this.ctx.strokeStyle = 'red';
        }
      }
      // draw
      this.draw(userAction, i, birdsTimeline, 0, 0, false);
      // sleep
      if (nextTime > 0 && nextTime < 1000) {
          await this.sleep(nextTime);
        this.ctx.clearRect(0, 0, 1000, 1000);
      } else {
        let j = 1;
        while (nextTime > 0) {
          this.ctx.clearRect(0, 0, 1000, 1000);
          this.draw(userAction, i - 1, birdsTimeline, j - 1, j + 1, false);
          await this.sleep(1000);
          nextTime -= 1000;
          this.ctx.clearRect(0, 0, 1000, 1000);
          j++;
          this.draw(userAction, i - 1, birdsTimeline, j - 1, j + 1, false);
        }
      }
    }
    const boatLocation = userAction.actions[userAction.actions.length - 1].latlngs;
    this.ctx.drawImage(this.boatImage, boatLocation.x, boatLocation.y, 50, 50);
    console.log('done');
    console.log((new Date().getTime() - this.timeOfShort) / 1000);
  }

  draw(userAction: IRemoteUserActions, i: number,
       birdsTimeline: IBirdTimeline, plus: number,
       add: number, isShort: boolean) {
    let boatLocation: IRemotePoint;
    if (isShort) {
      this.drawLineWithBuffer(userAction, i);
    } else {
      this.drawLine(userAction, i);
    }
    boatLocation = userAction.actions[i].latlngs;
    this.ctx.drawImage(this.boatImage, boatLocation.x, boatLocation.y, 50, 50);
    const realTimeMS = userAction.actions[i].realTime + plus;
    this.realTime = this.secondToHumanReadableSTR(Math.round(userAction.actions[i].realTime / 1000) + plus);
    if (userAction.actions[i + add].realTime < EXP_TIME) {
      console.log(userAction.actions[i + add].realTime);
      const birds = birdsTimeline.actions[realTimeMS].latlngs;
      this.ctx.font = '15px Segoe UI';
      for (let b = 0; b < birds.length; b++) {
        if (birds[b].Visited) {
          this.ctx.drawImage(this.redBirdImage, birds[b].x, birds[b].y, 50, 50);
        } else {
          this.ctx.drawImage(this.birdImage, birds[b].x, birds[b].y, 50, 50);
        }
        this.ctx.fillText(birds[b].TimeTag.toString(), birds[b].x, birds[b].y + 60);
      }
    }
    this.ctx.font = '30px Segoe UI';
    this.ctx.fillText('Timer: ' + this.realTime + '   RouteID: ' + userAction.actions[i].id, 10, 50);
  }

  drawLineWithBuffer(userAction: IRemoteUserActions, index: number) {
    const s = userAction.actions[index++].latlngs;
    const e = index + (this.buffer - (index % this.buffer));
    const routeId = userAction.actions[index].id;
    this.ctx.beginPath();
    this.ctx.moveTo(s.x, s.y);
    while (index < userAction.actions.length && !userAction.actions[index].endRoute &&
           routeId === userAction.actions[index].id && index < e) {
      const p = userAction.actions[index++].latlngs;
      this.ctx.lineTo(p.x, p.y);
    }
    this.ctx.stroke();
  }

  drawLine(userAction: IRemoteUserActions, index: number) {
    const s = userAction.actions[index++].latlngs;
    const routeId = userAction.actions[index].id;
    this.ctx.beginPath();
    this.ctx.moveTo(s.x, s.y);
    while (index < userAction.actions.length && !userAction.actions[index].endRoute &&
           routeId === userAction.actions[index].id) {
      const p = userAction.actions[index++].latlngs;
      this.ctx.lineTo(p.x, p.y);
    }
    this.ctx.stroke();
  }

  findNextActionTime(userAction: IRemoteAction[], index: number): number[] {
    while (userAction[index] && !userAction[index++].endRoute) {
    }
    if (index === userAction.length) {
      return [-1, userAction[index - 1].time];
    }
    return [userAction[index].time, userAction[index - 1].time];
  }

  extractFeatures(userAction: IRemoteAction[]): ITimelinePoint[] {
    const newUserAction: IRemoteAction[] = [];
    const timeline: ITimelinePoint[] = [];
    let time;
    for (time = 0; time < userAction[0].time; time += 4) {
      const features: IFeatures = {
        backgroundPath: false,
        idelTime: time,
        regret: userAction[0].regret,
        timeFromLastDesicion: -1,
        timeTillNextDesicion: userAction[0].time - time,
        timeTillPathDone: -1
      };
      timeline.push({
        latlng: userAction[0].latlngs,
        time: time,
        features: features,
        endRoute: false,
        id: userAction[0].id
      });
    }
    let lastActionTime = userAction[0].time;
    let nextActionTime = this.findNextActionTime(userAction, 0);
    for (let i = 0; i < userAction.length - 1; i++) {
      if (!userAction[i].endRoute) {
        const features: IFeatures = {
          backgroundPath: true,
          idelTime: 0,
          regret: userAction[i].regret,
          timeFromLastDesicion: userAction[i].time - lastActionTime,
          timeTillNextDesicion: nextActionTime[0] - time,
          timeTillPathDone: nextActionTime[1] - time
        };
        timeline.push({
          latlng: userAction[i].latlngs,
          time: userAction[i].time,
          features: features,
          endRoute: false,
          id: userAction[i].id
        });
        continue;
      }
      for (time = userAction[i].time + 4; time < userAction[i + 1].time; time += 4) {
        const features: IFeatures = {
          backgroundPath: false,
          idelTime: time - userAction[i].time,
          regret: userAction[i].regret,
          timeFromLastDesicion: time - lastActionTime,
          timeTillNextDesicion: userAction[i + 1].time - time,
          timeTillPathDone: -1
        };
        timeline.push({
          latlng: userAction[i].latlngs,
          time: time,
          features: features,
          endRoute: true,
          id: userAction[i].id
        });
      }
      lastActionTime = userAction[i + 1].time;
      nextActionTime = this.findNextActionTime(userAction, i + 1);
    }
    return timeline;
  }

  scoreByTimeLine(timeLine: ITimelinePoint[]): ITimeAndScore[] {
    const timeAndScore: ITimeAndScore[] = [];
    for (let i = 0; i < timeLine.length; i++) {
      timeAndScore.push({time: timeLine[i].time,
                        score: this.scoreByFeatures(timeLine[i].features),
                        latlng: timeLine[i].latlng,
                        endRoute: timeLine[i].endRoute,
                        id: timeLine[i].id});
    }
    return timeAndScore;
  }

  chooseRandomPoints(timeLine: ITimeAndScore[], interval: number, buffer: number) {
    const shortPath: IRemoteUserActions = {
      actions: [],
      date: Date.now().toString(),
      pool: 'game',
      userId: 'A1VSXOCH5ILDOR'
    };
    let newTime = 0;
    for (let i = 0; i < timeLine.length; i += interval) {
      const rnd = this.getRandomArbitrary(0, 1);
      const end = (i + interval) > timeLine.length ? timeLine.length : i + interval;
      let index: number;
      if (rnd < 0.5) {
        index = this.chooseMaxFromInterval(timeLine, i, end);
        shortPath.actions = shortPath.actions.concat(this.getLatLngsWithBuffer(timeLine, index, buffer, newTime, 1));
      } else {
        index = this.chooseMinFromInterval(timeLine, i, end);
        shortPath.actions = shortPath.actions.concat(this.getLatLngsWithBuffer(timeLine, index, buffer, newTime, 0));
      }
      newTime += buffer + 300;
    }
    console.log(shortPath);
    return shortPath;
  }

  getLatLngsWithBuffer(timeLine: ITimeAndScore[], index: number,
                       buffer: number, newTime: number, type: number): IRemoteAction[] {
    let left = index - Math.round(buffer / 2);
    let right = index + Math.round(buffer / 2);
    const latlngs: IRemoteAction[] = [];
    if (left < 0) {
      left = 0;
    }
    if (right > timeLine.length) {
      right = timeLine.length;
    }
    const currentTime = newTime;
    for (let i = left; i < right - 1; i++) {
      latlngs.push({time: newTime, latlngs: timeLine[i].latlng,
                    realTime: timeLine[i].time, type: type,
                    endRoute: timeLine[i].endRoute,
                    regret: Regret.DontCare,
                    id: timeLine[i].id});
      newTime += timeLine[i + 1].time - timeLine[i].time;
      if (newTime - currentTime >= buffer) {
        break;
      }
    }
    return latlngs;
  }

  chooseMaxFromInterval(timeLine: ITimeAndScore[], start: number, end: number) {
    let index = start;
    for (let i = start; i < end; i += 1) {
      if (i > timeLine.length) {
        break;
      }
      if (timeLine[index].score < timeLine[i].score) {
        index = i;
      } else {
        if (timeLine[index].score === timeLine[i].score ) {
          const rnd = this.getRandomArbitrary(0, 1);
          if (rnd > 0.5) {
            index = i;
          }
        }
      }
    }
    return index;
  }

  chooseMinFromInterval(timeLine: ITimeAndScore[], start: number, end: number) {
    let index = start;
    for (let i = start; i < end; i += 1) {
      if (i > timeLine.length) {
        break;
      }
      if (timeLine[index].score > timeLine[i].score ) {
        index = i;
      } else {
        if (timeLine[index].score === timeLine[i].score ) {
          const rnd = this.getRandomArbitrary(0, 1);
          if (rnd > 0.5) {
            index = i;
          }
        }
      }
    }
    return index;
  }

  scoreByFeaturesRandom(features: IFeatures): number {
    let score = this.getRandomArbitrary(5, 10);
    if (features.backgroundPath) {
      score = this.getRandomArbitrary(0, 5);
    }
    score += 1.4 * this.normalizeBetweenAToBInRange((features.timeFromLastDesicion / 1000), 1, 7, 0, 120);
    score += 0.7 * this.normalizeBetweenAToBInRange((features.timeTillPathDone / 1000), -3, 3, 0, 120);
    if (score > 10) {
      score = 10;
    }
    if (score < 0) {
      score = 0;
    }
    return Math.ceil(score);
  }


  scoreByFeatures(features: IFeatures): number {
    let score = Math.pow(features.idelTime / 1000, 2);
    score += Math.pow(features.timeFromLastDesicion / 1000, 2);
    score += Math.pow(features.timeTillNextDesicion / 1000, 2);
    switch (features.regret) {
      case Regret.No:
        break;
      case Regret.After:
        score = -Math.pow(10, 10);
        break;
      case Regret.Before:
        score = Math.pow(10, 10);
        break;
      default:
    }
    if (!features.backgroundPath) {
      score = Math.pow(score, 2);
    }
    return score;
  }

  getRandomArbitrary(min: number, max: number) {
    return Math.random() * (max - min) + min;
  }

  normalizeBetweenAToBInRange(x: number, a: number, b: number, min: number, max: number) {
    return a + (x - min) * (b - a) / (max - min);
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  createBirdTimeline(birdConfig: IBirdConfig[]): IBirdTimeline {
    const birdsTimeline: IBirdTimeline = {
      actions: []
    };
    for (let i = 0; i < EXP_TIME + 2000; i++ ) {
      birdsTimeline.actions.push({time: i, latlngs: []});
    }
    for (let i = 0; i < birdConfig.length; i++) {
      const bird = birdConfig[i];
      const birdTimeS = bird.ArrivalTime; // + 1000; // * 1000;
      const birdTimeE = bird.DepartureTime + this.add; // * 1000;
      for (let j = birdTimeS; j < birdTimeE; j++) {
        birdsTimeline.actions[j].latlngs.push({x: bird.X, y: bird.Y,
                                               Visited: bird.IsChased === 1,
                                               TimeTag: birdTimeE / 1000});
      }
    }
    return birdsTimeline;
  }

  ngOnInit() {
    this.ctx = this.canvasRef.nativeElement.getContext('2d');
    this.redBirdImage = new Image();
    this.redBirdImage.src = '../../assets/red_bird.png';
    this.birdImage = new Image();
    this.birdImage.src = '../../assets/bird.png';
    this.boatImage = new Image();
    this.boatImage.src = '../../assets/boat.png';
    this.boatImage.onload = () => {
      this.route.queryParams
      .subscribe(params => {
        this.interval = params['interval'] ? Number(params['interval']) : 10000;
        this.interval /= 6;
        this.SenarioId = params['senario'] ? Number(params['senario']) : 3;
        this.buffer = params['buffer'] ? Number(params['buffer']) : 500;
        this.full = params['full'] ? true : false;
        this.add = params['add'] ? Number(params['add']) : 0;
        this.userService.getRemoteBirds(this.SenarioId).subscribe(
          (birdConfig: IBirdConfig[]) => {
            const birdTimeline: IBirdTimeline = this.createBirdTimeline(birdConfig);
            this.getRemoteRoute(this.SenarioId, birdTimeline);
          });
      });
    };
  }

}
