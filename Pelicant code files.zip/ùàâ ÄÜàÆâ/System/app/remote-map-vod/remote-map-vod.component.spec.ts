import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoteMapVodComponent } from './remote-map-vod.component';

describe('RemoteMapVodComponent', () => {
  let component: RemoteMapVodComponent;
  let fixture: ComponentFixture<RemoteMapVodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoteMapVodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoteMapVodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
