import { Component, OnInit, Input, Output, OnDestroy, EventEmitter } from '@angular/core';
import { Observable, Subscription } from 'rxjs/Rx';
import { MatSnackBar } from '@angular/material';
import * as L from 'leaflet';
import * as turf from 'turf';
import booleanContains from '@turf/boolean-contains';
import shortestPath from '@turf/shortest-path';
import bezierSpline from '@turf/bezier-spline';
import inside from '@turf/inside';
import { Polyline } from 'leaflet';
import { IObstacle } from '../managment/pool-information/pool-information.component';
import { UserManagerService, IUserActions, IAction } from '../managment/user-list/user-manager.service';


interface IBirdJSON {
  start: number;
  end: number;
  coordination: L.LatLng;
}

const birdsJSON: IBirdJSON[] = [
  {start: 1, end: 11, coordination: (new L.LatLng(32.64670, 35.24780))},
  {start: 10, end: 100, coordination: (new L.LatLng(32.64673, 35.25060))},
  {start: 17, end: 100, coordination: (new L.LatLng(32.64670, 35.24780))},
  {start: 30, end: 100, coordination: (new L.LatLng(32.64668, 35.25063))},
  {start: 38, end: 170, coordination: (new L.LatLng(32.64673, 35.25060))}
];

interface IFlagByReference {
  flag: boolean;
}

interface ICurrentMarkers {
  markers: L.Marker[];
  numberOfVanished: number;
}

//Am
interface ILocationByReference {
  currLocation: L.LatLng;
}

const currentBirds: ICurrentMarkers = {
  markers: [],
  numberOfVanished: 0
};

const animationSpeed = 0.000075;

let pathToSend: IAction[] = [];

@Component({
  selector: 'app-map-player',
  templateUrl: './map-player.component.html',
  styleUrls: ['./map-player.component.scss']
})
export class MapPlayerComponent implements OnInit, OnDestroy {

  //Am
  destinationInfo: string; //Am
  @Output() messageEvent = new EventEmitter<string>(); //Am
  public myTry: string;
  locationUpdater : ILocationByReference;
  

  @Input() height: number;
  @Input() bounds: L.LatLng[];
  @Input() inputObstacels: IObstacle[];
  @Input() user: string;
  @Input() pool: string;
  @Output('gameOver') gameOver = new EventEmitter<any>();
  @Output('timeAndScore') timeAndScore = new EventEmitter<string>();

  options;
  map: L.Map;
  boatLocation: L.LatLng;
  bird: any;
  boatIcon:  L.Icon;
  birdIcon: L.Icon;
  line: L.Polyline = null;
  path: L.LatLng[] = null;
  boundaries: L.Polygon;
  obstecles: L.Polygon[];

  start = false;
  polyline: L.Polyline;
  latlngs: L.LatLng[] = [];
  turfPolyBound: any;

  tick;
  timer;
  lastLayer;
  sub: Subscription;

  userActions: IUserActions;
  stopAnimeFlag: IFlagByReference;
  isInSideAnime: boolean;

  tempPolyline: L.Polyline;

  constructor(private userService: UserManagerService,
              public snackBar: MatSnackBar) {

    this.boatLocation = new L.LatLng(32.64716, 35.2488);//not me

    this.myTry = "abcd"; //Am
    this.locationUpdater = {currLocation: this.boatLocation}; //Am



    this.stopAnimeFlag = {flag: false};
    this.isInSideAnime = false;
    this.obstecles = [];
    this.lastLayer = null;


    this.boatIcon = L.icon({
      iconUrl: '../../assets/boat.png',
      iconSize:     [30, 30]
    });

    this.birdIcon = L.icon({
      iconUrl: '../../assets/bird.png',
      iconSize:     [30, 30]
    });
  }

  drawBoat(latlng: L.LatLng, map: L.Map) {
    this.boatLocation = latlng;
    const boat = L.marker(latlng, {icon: this.boatIcon});
    boat.addTo(map);
    return boat;
  }

  drawBird(latlng: L.LatLng, map: L.Map) {
    const bird = L.marker(latlng, {icon: this.birdIcon});
    bird.addTo(map);
    currentBirds.markers.push(bird);
    return bird;
  }

  fitBoundsByChange(selectedbounds: L.LatLng[]) {
    const bounds: L.LatLngBounds = L.latLngBounds(selectedbounds);
    this.map.dragging.disable();
    this.map.fitBounds(bounds, {
      padding: L.point(24, 24),
      maxZoom: 18,
      animate: true
    });
  }

  createTurfPolygon(poly: L.Polygon) {
    const newCoords = [];
    const  coords = poly.toGeoJSON().geometry.coordinates[0];
    for (let i = 0; i < coords.length; i++) {
      newCoords.push([coords[i][1], coords[i][0]]);
    }
    return turf.polygon([newCoords]);
  }

  addBirdAnimation(birdData: IBirdJSON)  {
    const bird = this.drawBird(birdData.coordination, this.map);
    setTimeout(() => {
      for (let i = 0; i < currentBirds.markers.length; i++) {
        if (currentBirds.markers[i] === bird) {
          currentBirds.markers.splice(i, 1);
          this.map.removeLayer(bird);
          break;
        }
      }
    }, 1000 * (birdData.end - birdData.start));
  }

  initializeBirdsInject(birdsjson: IBirdJSON[]) {
    for (let i = 0 ; i < birdsjson.length ; i++) {
      setTimeout(this.addBirdAnimation.bind(this), 1000 * birdsjson[i].start, birdsjson[i]);
    }
  }

  addObstecle(points: L.LatLng[]) {
    const polygon = new L.Polygon(points);
    polygon.setStyle({fillColor: 'red'});
    polygon.setStyle({color: 'red'});
    polygon.setStyle({fillOpacity: 100});
    this.map.addLayer(polygon);
    this.obstecles.push(polygon);
  }

  isIntersecting(path: L.Polyline) {
    for (let i = 0; i < this.obstecles.length; i++) {
      if (turf.intersect(this.obstecles[i].toGeoJSON(), path.toGeoJSON())) {
        return true;
      }
    }
    return false;
  }

  createTurfObsteclesList() {
    const list = [];
    for (let i = 0; i < this.obstecles.length; i++) {
      list.push(this.createTurfPolygon(this.obstecles[i]));
    }
    return list;
  }

  validateClick (point) {
    if (this.boundaries.getBounds().intersects([point])) {
      return false;
    }
    return true;
  }

  disableZoom(map: L.Map) {
    map.touchZoom.disable();
    map.doubleClickZoom.disable();
    map.scrollWheelZoom.disable();
    map.boxZoom.disable();
    map.keyboard.disable();
  }

  addUserAction (timeStamp: IAction[]) {
    timeStamp.push({time: -1, latlngs: null});
    if (this.user) {
      this.userService.addTospecificUserActions({
        date: this.userActions.date,
        pool: this.userActions.pool,
        userId: this.userActions.userId,
        actions: timeStamp
      }).subscribe();
      this.userActions.actions = this.userActions.actions.concat(timeStamp);
    }
  }

  drawPolyline(latlngs: L.LatLng[], map: L.Map) {
    this.polyline = new L.Polyline(latlngs, {
      color: 'green',
      weight: 3,
      opacity: 1,
      smoothFactor: 1
    });
    map.addLayer(this.polyline);
  }

  drawTempPolyline(latlngs: L.LatLng[], map: L.Map) {

    //Am
//    this.latlngs[0] = this.boatLocation;
      this.latlngs[0] = this.locationUpdater.currLocation;

    this.tempPolyline = new L.Polyline(latlngs, {
      color: 'red',
      weight: 3,
      opacity: 1,
      smoothFactor: 1
    });
    console.log("drawTempPolyline");
    console.log(latlngs);    
    map.addLayer(this.tempPolyline);
  }

  bezierPath(latlngs: L.LatLng[]): L.LatLng[] {
    const currentPath = [];
    for (let i = 0; i < latlngs.length; i++) {
      currentPath.push([latlngs[i].lat, latlngs[i].lng]);
    }
    const curved  = bezierSpline(turf.lineString(currentPath), {
                                  resolution: 10000,
                                  sharpness: 1
                                }).geometry.coordinates;
    const currentPathLatLngs = [];
    for (let i = 0; i < curved.length; i += 2) {
      currentPathLatLngs.push(L.latLng(curved[i][0], curved[i][1]));
    }
    return currentPathLatLngs;
  }

  oneClickPath(map: L.Map): L.LatLng[] {
    this.polyline = new L.Polyline(this.latlngs);
    const start = [this.latlngs[0].lat, this.latlngs[0].lng];
    const end = [this.latlngs[1].lat, this.latlngs[1].lng];
    if ((this.validateClick(end) || this.isIntersecting(this.polyline))) {
      // alert('invalid path');
      this.snackBar.open('invalid path - path inside obstecle or out of pool range', 'invalid path', {
        duration: 2000
      });
      this.map.removeLayer(this.tempPolyline);
      return null;
    }
    return this.bezierPath(this.latlngs);
  }

  dragClickPath(map: L.Map): L.LatLng[] {
    this.polyline = new L.Polyline(this.latlngs);
    this.polyline.setStyle({color: 'yellow'});
    const start = [this.latlngs[0].lat, this.latlngs[0].lng];
    const end = [this.latlngs[this.latlngs.length - 1].lat, this.latlngs[this.latlngs.length - 1].lng];
    if (this.validateClick(end) || this.isIntersecting(this.polyline)) {
        // alert('path inside obstecle');
        this.snackBar.open('invalid path - path inside obstecle or out of pool range', 'invalid path', {
          duration: 2000
        });
        this.map.removeLayer(this.tempPolyline);//am2
        return null;
    }
    return this.bezierPath(this.latlngs);
  }

  onMapReady(map: L.Map) {
    this.map = map;
    this.map.invalidateSize();
    this.map.on(L.Draw.Event.CREATED /*some event*/, (event: any) => {});
    this.map.dragging.disable();

    if (this.inputObstacels) {
      for (let i = 0; i < this.inputObstacels.length; i++) {
        this.addObstecle(this.inputObstacels[i].polygon);
      }
    }

    if (this.bounds) {
      this.fitBoundsByChange(this.bounds);
      this.boundaries = new L.Polygon(this.bounds);
      this.turfPolyBound = turf.polygon(this.bounds);
    }

    this.disableZoom(this.map);
    this.initializeBirdsInject(this.randomBirdObject());
    let boat = this.drawBoat(this.boatLocation, this.map);

    // converts from touch to mouse event !
    function touchHandler(event) {
      const touches = event.changedTouches;
      const first = touches[0];
      let type = '';
      switch (event.type) {
          case 'touchstart': type = 'mousedown'; break;
          case 'touchmove':  type = 'mousemove'; break;
          case 'touchend':   type = 'mouseup';   break;
          default:           return;
      }

      const simulatedEvent = document.createEvent('MouseEvent');
      simulatedEvent.initMouseEvent(type, true, true, window, 1,
                                    first.screenX, first.screenY,
                                    first.clientX, first.clientY, false,
                                    false, false, false, 0, null);

      first.target.dispatchEvent(simulatedEvent);
      event.preventDefault();
    }

    this.map.on('mousedown', (event: any) => {
      this.start = true;
      if (this.isInSideAnime) {
        this.stopAnimeFlag.flag = true;
      }
      // location => {
      //   this.boatLocation = location;
      // }
      this.latlngs.push(this.boatLocation);
      this.latlngs.push(event.latlng);
      console.log("12345");
      console.log(event.latlng);
       //Am
      // let X = event.latlng.lat;
      // let Y = event.latlng.lng;
      // this.destinationInfo = X.toString().substring(0, 8) + ' , ' + Y.toString().substring(0, 8);
      

      

//    this.destinationInfo=attribution;
//    this.destChange.emit(this.destData);
  //  console.log(this.destData);
    //   var myLatLng = event.latLng;
    // var lat = myLatLng.lat();
    // var lng = myLatLng.lng();
    // console.log("b123");
    //   console.log(lat);


      this.drawTempPolyline(this.latlngs, this.map); //Draw the temp red line

      if (this.polyline) {
        map.removeLayer(this.polyline);
      }
    });

    this.map.on('mousemove', (event: any) => {
      if (this.start) {
        if (this.validateClick(event.latlng)) {
          // alert('invalid path');
          this.snackBar.open('invalid path - path inside obstecle or out of pool range', 'invalid path', {
            duration: 2000
          });
          this.map.removeLayer(this.tempPolyline); //AM
          this.latlngs = [];
          this.start = false;
          return;
        }
        this.latlngs.push(event.latlng);
        this.map.removeLayer(this.tempPolyline);
        this.drawTempPolyline(this.latlngs, this.map);
        if (this.isInSideAnime) {
          this.stopAnimeFlag.flag = true;
        }
      }
    });

    this.map.on('mouseup', (event: any) => {
      this.start = false;
      let newPath: L.LatLng[] = null;
      if (this.isInSideAnime) {
        this.stopAnimeFlag.flag = true;
      }
      this.latlngs[0] = this.boatLocation;
      if (this.latlngs.length > 2) {
        newPath = this.dragClickPath(map);
      } else {
        newPath = this.oneClickPath(map);
      }
      this.map.removeLayer(this.tempPolyline);
      if (newPath) {

        //Change the Destination //Am
        let X = event.latlng.lat;
        let Y = event.latlng.lng;
        this.destinationInfo = X.toString().substring(0, 8) + ' , ' + Y.toString().substring(0, 8);
        this.messageEvent.emit(this.destinationInfo);


        this.drawPolyline(newPath, map);
        this.isInSideAnime = true;

        boatAnime(newPath.length, newPath, this.boatIcon,
          this.polyline, this.boatLocation, this.stopAnimeFlag, this.locationUpdater)
        .then(location => {

          //When boat finished
          console.log("location");
          console.log(location);
          this.destinationInfo = "";
          this.messageEvent.emit(this.destinationInfo);    

          this.boatLocation = location;
          this.stopAnimeFlag.flag = false;
          this.isInSideAnime = false;
          // send data
          if (this.user) {
            this.addUserAction(pathToSend);
          }
          pathToSend = [];
        });
      }
      else { //Case of bad Path - Clear Destination
        this.destinationInfo = "";
        this.messageEvent.emit(this.destinationInfo);
      }
      this.latlngs = [];
    });

    //AM
    //Original: async function boatAnime
    //aa
    async function boatAnime(len: number, latlngs: L.LatLng[], icon: L.Icon,
                             polyline: L.Polyline, boatLoc: L.LatLng,
                             stopFlag: IFlagByReference, updateLocation : ILocationByReference) {
      let currentLength;
      console.log("in assync");
      // try{
      //   this.myTry = "a1a2a3";
      //   console.log("succsses");  
      // } catch(err) {
      //   console.log("fail");  
      //   console.log(err);  
      // }
      //console.log("len:")
      //console.log(len) 
      for (let i = 0; i < len; i++) {
        if (i < len - 1) {
          currentLength = turf.distance(turf.point([latlngs[i].lat, latlngs[i].lng]),
                                  turf.point([latlngs[i + 1].lat, latlngs[i + 1].lng]));
        }

        map.removeLayer(boat);
        boatLoc = latlngs[i];

        updateLocation.currLocation = boatLoc; //Am
        
        
        boat = L.marker(latlngs[i], {icon: icon});
        boat.addTo(map);
        pathToSend.push({time: new Date().getTime(), latlngs: latlngs[i]});
        birdVanish(latlngs, i);
        if (stopFlag.flag) {
          break;
        }
       // console.log(boatLoc);
        await sleep(currentLength / animationSpeed - 1.5);
      }
      //When boat finished the travel
      console.log("finished. boat loc:");      
      console.log(boatLoc);


      map.removeLayer(polyline);
      return boatLoc;
    }

    function birdVanish(latlngs: L.LatLng[], i: number) {
      const indexes: number[] = [];
      if (currentBirds) {
        for (let j = 0; j < currentBirds.markers.length; j++) {
          const jBird = currentBirds.markers[j];
          if (turf.distance(turf.point([latlngs[i].lat, latlngs[i].lng]),
            turf.point([jBird.getLatLng().lat, jBird.getLatLng().lng])) <= 0.04) {
            map.removeLayer(jBird);
            indexes.push(j);
            currentBirds.numberOfVanished++;
          }
        }
        for (let j = 0; j < indexes.length; j++) {
          currentBirds.markers.splice(indexes[j], 1);
        }
      }
    }

    function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Attach the mobile events that delegate to the desktop events.
    this.map.getContainer().addEventListener('touchstart',  touchHandler, true);
    this.map.getContainer().addEventListener('touchmove', touchHandler, true);
    this.map.getContainer().addEventListener('touchend', touchHandler, true);
  }

  secondToHumanReadableSTR(seconds: number) {
    const numminutes = Math.floor((((seconds % 31536000) % 86400) % 3600) / 60);
    const numseconds = (((seconds % 31536000) % 86400) % 3600) % 60;
    let numsecondsSTR = '' + numseconds;
    let numminutesSTR = '' + numminutes;
    if (numseconds < 10) {
      numsecondsSTR = '0' + numseconds;
    }
    if (numminutes < 10) {
      numminutesSTR = '0' + numminutes;
    }
    return numminutesSTR + ':' + numsecondsSTR;
  }

  addTimeToMap(seconds: number) {
    if (this.map) {
      const time = this.secondToHumanReadableSTR(seconds);
      const timerLabel = 'Timer - ' + time + ' - The game is till 10:00';
      const scoreLabel = 'Score - ' + currentBirds.numberOfVanished;
      const attribution = timerLabel + ' | ' + scoreLabel;
      if (this.lastLayer) {
        this.map.removeLayer(this.lastLayer);
      }
      this.timeAndScore.emit(attribution);
      this.lastLayer = L.tileLayer('', {
        attribution: attribution
      }).addTo(this.map);
    }
  }

  ngOnDestroy(): void {
    if (this.userActions) {
      this.sub.unsubscribe();
    }
  }

  randomPossionNumber(lamda: number): number {
    const l = Math.exp(-lamda);
    let p = 1.0;
    let k = 0;
    do {
      k++;
      p *= Math.random();
    } while (p > l);
    return k - 1;
  }

  getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
  }

  randomPointInPolygon(polygon: L.Polygon, obstacles: L.Polygon[]): L.LatLng {
    const bounds = polygon.getBounds();
    const x_min  = bounds.getEast();
    const x_max  = bounds.getWest();
    const y_min  = bounds.getSouth();
    const y_max  = bounds.getNorth();

    while (true) {

      const lat = this.getRandomArbitrary(y_min, y_max);
      const lng = this.getRandomArbitrary(x_min, x_max);

      const point  = turf.point([lng, lat]);
      let isGoodPoint = turf.inside(point, polygon.toGeoJSON());
      let i = 0;
      while (isGoodPoint && i < obstacles.length) {
        isGoodPoint = !turf.inside(point, obstacles[i].toGeoJSON());
        i++;
      }
      if (isGoodPoint) {
          return new L.LatLng(lat, lng);
      }
    }
  }

  randomBirdObject(): IBirdJSON[] {
    const birds: IBirdJSON[] = [];
    const obstacles: L.Polygon[] = [];
    if (this.inputObstacels) {
      for (let i = 0; i < this.inputObstacels.length; i++) {
        obstacles.push(new L.Polygon(this.inputObstacels[i].polygon));
      }
    }
    let s = 0, e = 45;
    for (let i = 0; i < 14; i++) {
      for (let j = 0; j < 7; j++) {
        const coordinate = this.randomPointInPolygon(this.boundaries, obstacles);
        const start = Math.round(this.getRandomArbitrary(s, s + 25));
        const end = Math.round(this.getRandomArbitrary(start + 10, e - 5));
        birds.push({coordination: coordinate, start: start, end: end});
      }
      s += 20;
      e += Math.round(this.getRandomArbitrary(20, 45));
    }
    return birds;
  }

  ngOnInit() {
   


    this.options = {
      layers: [
        L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
          subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            maxZoom: 22,
            maxNativeZoom: 22,
            attribution: '',
        })
      ],
      zoom: 15,
      zoomControl: false,
      center: L.latLng(32.64716, 35.2488)
    };
    if (this.user) {
      this.userActions = {
                          userId: this.user,
                          pool: this.pool,
                          actions: [{time: new Date().getTime(), latlngs: new L.LatLng(32.6374953832361, 35.209636939689524)}],
                          date: Date.now().toString()
                        };
      this.userService.addUserActions(this.userActions).subscribe();
      this.timer = Observable.timer(0, 1000);
      // subscribing to a observable returns a subscription object
      this.sub = this.timer.subscribe(t => {
        this.tick = t;
        this.addTimeToMap(this.tick);
        // after 10 min stop the timer.
        if (this.tick === 120) {
          this.gameOver.emit();
          this.sub.unsubscribe();
        }
      });
    }
  }

}
