import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapPlayerComponent } from './map-player.component';

describe('MapPlayerComponent', () => {
  let component: MapPlayerComponent;
  let fixture: ComponentFixture<MapPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
