import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapVodComponent } from './map-vod.component';

describe('MapVodComponent', () => {
  let component: MapVodComponent;
  let fixture: ComponentFixture<MapVodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapVodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapVodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
