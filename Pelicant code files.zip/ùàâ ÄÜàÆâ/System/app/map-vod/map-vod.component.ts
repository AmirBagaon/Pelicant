import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import * as L from 'leaflet';
import * as turf from 'turf';
import { IObstacle } from '../managment/pool-information/pool-information.component';
import { UserManagerService, IUserActions, IAction } from '../managment/user-list/user-manager.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
import { feature } from '@turf/helpers';

interface ICurrentMarkers {
  markers: L.Marker[];
  numberOfVanished: number;
}

interface ITimeLinePointFeatures {
  latlng: L.LatLng;
  backgroundPath: boolean;
  leftLenPath: number;
  timeFromLastAction: number;
}

interface ITimeLinePoint {
  time: number;
  features: ITimeLinePointFeatures;
}

interface ITimeAndIndex {
  time: number;
  index: number;
}

interface ITimeAndScore {
  time: number;
  score: number;
  latlng: L.LatLng;
}

const animationSpeed = 0.000075;

const birdsJSON = [
  {start: 1, end: 11, coordination: (new L.LatLng(32.64670, 35.24780))},
  {start: 10, end: 100, coordination: (new L.LatLng(32.64673, 35.25060))},
  {start: 17, end: 100, coordination: (new L.LatLng(32.64670, 35.24780))},
  {start: 30, end: 100, coordination: (new L.LatLng(32.64668, 35.25063))},
  {start: 38, end: 170, coordination: (new L.LatLng(32.64673, 35.25060))}
];

const birdsGameJSON = [
  {start: 1, end: 100, coordination: (new L.LatLng(32.64087431552352, 35.20603205077351))},
  {start: 10, end: 100, coordination: (new L.LatLng(32.638434992190845,  35.20298506133259))},
  {start: 17, end: 100, coordination: (new L.LatLng(32.636609973459144, 35.20354296080769))},
  {start: 30, end: 100, coordination: (new L.LatLng(32.640241904750376,  35.200860751792796))},
  {start: 38, end: 170, coordination: (new L.LatLng(32.64069362718742, 35.21092440001667))}
];

const birdsJSONByPool = {
  'pool 1': birdsJSON,
  'game': birdsGameJSON
};

const boatLocByPool = {
  'pool 1': new L.LatLng(32.64716, 35.2488),
  'game': new L.LatLng(32.6374953832361, 35.209636939689524)
};
const animeTime = 4;
const currentBirds: ICurrentMarkers = {
  markers: [],
  numberOfVanished: 0
};

@Component({
  selector: 'app-map-vod',
  templateUrl: './map-vod.component.html',
  styleUrls: ['./map-vod.component.scss']
})
export class MapVodComponent implements OnInit, OnDestroy {

  sub: Subscription;
  timer: Observable<number>;
  @Input() height: number;
  @Input() bounds: L.LatLng[];
  @Input() inputObstacels: IObstacle[];
  @Input() user: string;
  @Input() pool: string;
  @Input() date: string;

  boatIcon: L.Icon;
  boatLocation: L.LatLng;
  birdIcon: L.Icon;
  bird: L.Marker;
  map: L.Map;
  options;

  progressVal: number;

  constructor(private userService: UserManagerService) {
    this.progressVal = 0;
    this.boatIcon = L.icon({
      iconUrl: '../../assets/boat.png',
      iconSize:     [30, 30]
    });

    this.birdIcon = L.icon({
      iconUrl: '../../assets/bird.png',
      iconSize:     [30, 30]
    });
  }

  drawBoat(latlng: L.LatLng, map: L.Map) {
    this.boatLocation = latlng;
    const boat = L.marker(latlng, {icon: this.boatIcon});
    boat.addTo(map);
    return boat;
  }

  drawBird(latlng: L.LatLng, map: L.Map) {
    const bird = L.marker(latlng, {icon: this.birdIcon});
    bird.addTo(map);
    currentBirds.markers.push(bird);
    this.bird = bird;
    return bird;
  }

  fitBoundsByChange(selectedbounds: L.LatLng[]) {
    const bounds: L.LatLngBounds = L.latLngBounds(selectedbounds);
    this.map.dragging.disable();
    this.map.fitBounds(bounds, {
      padding: L.point(24, 24),
      maxZoom: 18,
      animate: true
    });
  }

  addBirdAnimation(birdData) {
    const bird = this.drawBird(birdData.coordination, this.map);
    setTimeout(() => {
      for (let i = 0; i < currentBirds.markers.length; i++) {
        if (currentBirds.markers[i] === bird) {
          currentBirds.markers.splice(i, 1);
          this.map.removeLayer(bird);
          break;
        }
      }
    }, 1000 * (birdData.end - birdData.start));
  }

  initializeBirdsInject(birdsjson) {
    for (let i = 0 ; i < birdsjson.length ; i++) {
      setTimeout(this.addBirdAnimation.bind(this), 1000 * birdsjson[i].start, birdsjson[i]);
    }
  }

  addObstecle(points: L.LatLng[]) {
    const polygon = new L.Polygon(points);
    polygon.setStyle({fillColor: 'red'});
    polygon.setStyle({color: 'red'});
    polygon.setStyle({fillOpacity: 100});
    this.map.addLayer(polygon);
  }

  disableZoom(map: L.Map) {
    map.touchZoom.disable();
    map.doubleClickZoom.disable();
    map.scrollWheelZoom.disable();
    map.boxZoom.disable();
    map.keyboard.disable();
  }

  onMapReady(map: L.Map) {
    this.map = map;
    this.map.invalidateSize();
    this.map.dragging.disable();
    this.disableZoom(this.map);

    if (this.inputObstacels) {
      for (let i = 0; i < this.inputObstacels.length; i++) {
        this.addObstecle(this.inputObstacels[i].polygon);
      }
    }

    if (this.bounds) {
      this.fitBoundsByChange(this.bounds);
    }

    this.boatLocation = boatLocByPool[this.pool];
    this.initializeBirdsInject(birdsJSONByPool[this.pool]);

    let boat = this.drawBoat(this.boatLocation, this.map);
    this.userService.getUserAction(this.user).subscribe(
      (userActions: IUserActions[]) => {
        let userAction: IUserActions;
        for (let i = 0; i < userActions.length; i++) {
          if (userActions[i].date === this.date) {
            userAction = userActions[i];
            break;
          }
        }
        /* the animation */
        if (userAction) {
          // playMapRecord(userAction, this.boatLocation, this.boatIcon, this.sub);
          const timeLine = extractFeatures(userAction);
          userAction = chooseRandomPoints(scoreByTimeLine(timeLine), 10000, 2000);
          playMapRecord(userAction, this.boatLocation, this.boatIcon, this.sub);
        }
    });

    async function playMapRecord(userAction: IUserActions, boatLocation: L.LatLng,
                           boatIcon: L.Icon, sub: Subscription) {
      let nextTime = 0;
      for (let i = 0; i < userAction.actions.length; i++) {
        if (userAction.actions[i].latlngs === null) {
          continue;
        }
        if (i + 1 < userAction.actions.length) {
          nextTime = userAction.actions[i + 1].time - userAction.actions[i].time;
        }
        if (boatLocation === userAction.actions[i].latlngs) {
          // await sleep(0.00);
          continue;
        }
        map.removeLayer(boat);
        boatLocation = userAction.actions[i].latlngs;
        boat = L.marker(boatLocation, {icon: boatIcon});
        boat.addTo(map);
        birdVanish([boatLocation], 0);
        if (nextTime > 0) {
          await sleep(nextTime * 20);
        }
      }
    }

    function extractFeatures(userAction: IUserActions): ITimeLinePoint[] {
      const timeLine: ITimeLinePoint[] = [];
      const newUserAction: IAction[] = [];
      const endPathTimes: ITimeAndIndex[] = [];
      const startPathTimes: ITimeAndIndex[] = [];
      let lastTimeAction = userAction.actions[0].time;
      let startPathTime = userAction.actions[1].time - userAction.actions[0].time;
      let k = 0;
      newUserAction.push({time: 0, latlngs: userAction.actions[0].latlngs});
      for (let i = 1; i < userAction.actions.length; i++) {
        if (userAction.actions[i].latlngs === null) {
          const endTimeMapped = userAction.actions[i - 1].time - userAction.actions[0].time;
          endPathTimes.push({time: endTimeMapped, index: i});
          startPathTimes.push({time: startPathTime, index: i});
          if (i + 1 < userAction.actions.length) {
            startPathTime = userAction.actions[i + 1].time - lastTimeAction;
          }
          continue;
        }
        const diffTimes = userAction.actions[i].time - lastTimeAction;
        const newTime = newUserAction[k].time + diffTimes;
        newUserAction.push({time: newTime, latlngs: userAction.actions[i].latlngs});
        k++;
        lastTimeAction = userAction.actions[i].time;
      }
      //
      lastTimeAction = 0;
      let pointFeatures: ITimeLinePointFeatures = {
        latlng: newUserAction[0].latlngs,
        backgroundPath: false,
        leftLenPath: -1,
        timeFromLastAction: 0
      };
      timeLine.push({time: 0, features: pointFeatures});
      for (let i = 0; i < newUserAction.length - 1; i++) {

        if (i !== 0) {
          pointFeatures = {
            latlng: newUserAction[i].latlngs,
            backgroundPath: true,
            leftLenPath: getTimeByIndex(i, endPathTimes) - newUserAction[i].time,
            timeFromLastAction: newUserAction[i].time - getTimeByIndex(i, startPathTimes)
          };
          timeLine.push({time: newUserAction[i].time, features: pointFeatures});
        }

        for (let j = newUserAction[i].time + 1; j < newUserAction[i + 1].time; j++) {
          let bgPath = true;
          let leftPath = getTimeByIndex(i, endPathTimes) - j;
          if (leftPath < 0) {
            bgPath = false;
            leftPath = -1;
          }
          pointFeatures = {
            latlng: newUserAction[i].latlngs,
            backgroundPath: bgPath,
            leftLenPath: leftPath,
            timeFromLastAction: j - getTimeByIndex(i, startPathTimes)
          };
          timeLine.push({time: j, features: pointFeatures});
        }
      }
      //
      const endTime = newUserAction[newUserAction.length - 1].time;
      const endLoc = newUserAction[newUserAction.length - 1].latlngs;
      const lastActionTime = getTimeByIndex(newUserAction.length - 1, startPathTimes);
      pointFeatures = {
        latlng: endLoc,
        backgroundPath: true,
        leftLenPath: 0,
        timeFromLastAction: endTime - lastActionTime
      };
      timeLine.push({time: endTime, features: pointFeatures});
      for (let i = endTime; i < 120000; i++) {
        pointFeatures = {
          latlng: endLoc,
          backgroundPath: false,
          leftLenPath: -1,
          timeFromLastAction: i - lastActionTime
        };
        timeLine.push({time: i, features: pointFeatures});
      }
      return timeLine;
    }

    function getTimeByIndex(index: number, PathTimes: ITimeAndIndex[]) {
      for (let i = 0; i < PathTimes.length; i++) {
        if (index < PathTimes[i].index) {
          return PathTimes[i].time;
        }
      }
      return -1;
    }

    function scoreByTimeLine(timeLine: ITimeLinePoint[]): ITimeAndScore[] {
      const timeAndScore: ITimeAndScore[] = [];
      for (let i = 0; i < timeLine.length; i++) {
        timeAndScore.push({time: timeLine[i].time,
                          score: scoreByFeatures(timeLine[i].features),
                          latlng: timeLine[i].features.latlng});
      }
      return timeAndScore;
    }

    function chooseRandomPoints(timeLine: ITimeAndScore[], interval: number, buffer: number) {
      const shortPath: IUserActions = {
        actions: [],
        date: Date.now().toString(),
        pool: 'game',
        userId: 'A1VSXOCH5ILDOR'
      };
      for (let i = 0; i < timeLine.length; i += interval) {
        const rnd = Math.round(getRandomArbitrary(0, 1));
        const end = (i + interval) > timeLine.length ? timeLine.length : i + interval;
        let index: number;
        if (rnd === 1) {
          index = chooseMaxFromInterval(timeLine, i, end);
        } else {
          index = chooseMinFromInterval(timeLine, i, end);
        }
        shortPath.actions = shortPath.actions.concat(getLatLngsWithBuffer(timeLine, index, buffer));
      }
      return shortPath;
    }

    function getLatLngsWithBuffer(timeLine: ITimeAndScore[], index: number, buffer: number): IAction[] {
      let left = index - Math.round(buffer / 2);
      let right = index + Math.round(buffer / 2);
      const latlngs: IAction[] = [];
      if (left < 0) {
        left = 0;
      }
      if (right > timeLine.length) {
        right = timeLine.length;
      }
      for (let i = left; i < right; i++) {
        latlngs.push({time: i, latlngs: timeLine[i].latlng});
      }
      return latlngs;
    }

    function chooseMaxFromInterval(timeLine: ITimeAndScore[], start: number, end: number) {
      let index = start;
      for (let i = start; i < end; i++) {
        if (timeLine[index].score < timeLine[i].score) {
          index = i;
        }
      }
      return index;
    }

    function chooseMinFromInterval(timeLine: ITimeAndScore[], start: number, end: number) {
      let index = start;
      for (let i = start; i < end; i++) {
        if (timeLine[index].score > timeLine[i].score ) {
          index = i;
        }
      }
      return index;
    }

    function scoreByFeatures(features: ITimeLinePointFeatures): number {
      let score = getRandomArbitrary(5, 10);
      if (features.backgroundPath) {
        score = getRandomArbitrary(0, 5);
      }
      score += 1.4 * normalizeBetweenAToBInRange((features.timeFromLastAction / 1000), 1, 7, 0, 120);
      score -= 0.7 * (3 - normalizeBetweenAToBInRange((features.leftLenPath / 1000), 1, 6, 0, 120));
      score += getRandomArbitrary(0, 4);
      if (score > 10) {
        score = 10;
      }
      if (score < 0) {
        score = 0;
      }
      return Math.ceil(score);
    }

    function getRandomArbitrary(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    function normalizeBetweenAToBInRange(x: number, a: number, b: number, min: number, max: number) {
      return a + (x - min) * (b - a) / (max - min);
    }

    function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    function pathTime(latlngs: L.LatLng[]) {
      const dist = turf.distance(turf.point([latlngs[0].lat, latlngs[0].lng]),
                    turf.point([latlngs[latlngs.length - 1].lat,
                                latlngs[latlngs.length - 1].lng]));
      return dist / animationSpeed / 1000;
    }

    function birdVanish(latlngs: L.LatLng[], i: number) {
      const indexes: number[] = [];
      if (currentBirds) {
        for (let j = 0; j < currentBirds.markers.length; j++) {
          const jBird = currentBirds.markers[j];
          if (turf.distance(turf.point([latlngs[i].lat, latlngs[i].lng]),
            turf.point([jBird.getLatLng().lat, jBird.getLatLng().lng])) <= 0.04) {
            map.removeLayer(jBird);
            indexes.push(j);
            currentBirds.numberOfVanished++;
          }
        }
        for (let j = 0; j < indexes.length; j++) {
          currentBirds.markers.splice(indexes[j], 1);
        }
      }
    }

  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  ngOnInit() {
    this.options = {
      layers: [
        L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
          subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            maxZoom: 18,
            attribution: '',
        })
      ],
      zoom: 15,
      zoomControl: false,
      center: L.latLng(32.64716, 35.2488)
    };
    this.timer = Observable.timer(0, 500);
    // subscribing to a observable returns a subscription object
    this.sub = this.timer.subscribe(t => {
      this.progressVal += 1;
    });
  }

}
