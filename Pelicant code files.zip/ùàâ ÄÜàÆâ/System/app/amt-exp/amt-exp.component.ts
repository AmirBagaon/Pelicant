import { Component, OnInit, Input, Inject } from '@angular/core';
import { IPoolInfo, IMapObject } from '../managment/pool-information/pool-information.component';
import { PoolManagerService } from '../managment/pool-list/pool-manager.service';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material';
import * as L from 'leaflet';
import { InstructionsDialog1Component } from './instructions-dialog-1/instructions-dialog-1.component';
import { SubmitDialogComponent } from './submit-dialog/submit-dialog.component';

const arr = [
  {lat: 32.642088338901964, lng: 35.20282328405302},
  {lat: 32.64213187731892, lng: 35.20916938763549},
  {lat: 32.64209021934448, lng: 35.20948469649739},
  {lat: 32.64200803386472, lng: 35.20983278940549},
  {lat: 32.64190100108204, lng: 35.210282206753625},
  {lat: 32.641686686997296, lng: 35.21069288268336},
  {lat: 32.64117825384336, lng: 35.211219191551216},
  {lat: 32.640572446608964, lng: 35.21173894419917},
  {lat: 32.64027029434856, lng: 35.211851001076866},
  {lat: 32.64000039111935, lng: 35.211930874065736},
  {lat: 32.63962332363746, lng: 35.21194756060141},
  {lat: 32.63924437420169, lng: 35.21187543890847},
  {lat: 32.63879665995436, lng: 35.2117359640397},
  {lat: 32.63823362681852, lng: 35.21150172062335},
  {lat: 32.63780334858935, lng: 35.21136522263987},
  {lat: 32.63730091645061, lng: 35.21109759763931},
  {lat: 32.63684867479412, lng: 35.210746526863666},
  {lat: 32.636658441681156, lng: 35.2105015516645},
  {lat: 32.63650183767229, lng: 35.210227966017555},
  {lat: 32.636667603621625, lng: 35.20883142962703},
  {lat: 32.63662744978173, lng: 35.20773470474524},
  {lat: 32.63662744978173, lng: 35.20611345869838},
  {lat: 32.63632917174247, lng: 35.20440578475245},
  {lat: 32.636306209590494, lng: 35.20272791633034},
  {lat: 32.636660449207454, lng: 35.20256280855392},
  {lat: 32.64040681568656, lng: 35.19986629398773},
  {lat: 32.64063970294138, lng: 35.199918747675845},
  {lat: 32.64087572714969, lng: 35.199919344886446},
  {lat: 32.64123710272121, lng: 35.20087301949388}
];

const poolAMT = {
  poolId: '5aa04c02e6529b0ff8c3338a',
  _id: 'game',
  bounds: [[
    {lat: 32.642088338901964, lng: 35.20282328405302},
    {lat: 32.64213187731892, lng: 35.20916938763549},
    {lat: 32.64209021934448, lng: 35.20948469649739},
    {lat: 32.64200803386472, lng: 35.20983278940549},
    {lat: 32.64190100108204, lng: 35.210282206753625},
    {lat: 32.641686686997296, lng: 35.21069288268336},
    {lat: 32.64117825384336, lng: 35.211219191551216},
    {lat: 32.640572446608964, lng: 35.21173894419917},
    {lat: 32.64027029434856, lng: 35.211851001076866},
    {lat: 32.64000039111935, lng: 35.211930874065736},
    {lat: 32.63962332363746, lng: 35.21194756060141},
    {lat: 32.63924437420169, lng: 35.21187543890847},
    {lat: 32.63879665995436, lng: 35.2117359640397},
    {lat: 32.63823362681852, lng: 35.21150172062335},
    {lat: 32.63780334858935, lng: 35.21136522263987},
    {lat: 32.63730091645061, lng: 35.21109759763931},
    {lat: 32.63684867479412, lng: 35.210746526863666},
    {lat: 32.636658441681156, lng: 35.2105015516645},
    {lat: 32.63650183767229, lng: 35.210227966017555},
    {lat: 32.636667603621625, lng: 35.20883142962703},
    {lat: 32.63662744978173, lng: 35.20773470474524},
    {lat: 32.63662744978173, lng: 35.20611345869838},
    {lat: 32.63632917174247, lng: 35.20440578475245},
    {lat: 32.636306209590494, lng: 35.20272791633034},
    {lat: 32.636660449207454, lng: 35.20256280855392},
    {lat: 32.64040681568656, lng: 35.19986629398773},
    {lat: 32.64063970294138, lng: 35.199918747675845},
    {lat: 32.64087572714969, lng: 35.199919344886446},
    {lat: 32.64123710272121, lng: 35.20087301949388}
  ].map(x => new L.LatLng(x.lat, x.lng))]
};

const obstaclesAMT = [
  {
    polygon: [
      {lat: 32.64022970181646, lng: 35.20159512765532},
      {lat: 32.6404304671629, lng: 35.20197659854603},
      {lat: 32.640450544334456, lng: 35.202405751988415},
      {lat: 32.64035016063726, lng: 35.20300179829065},
      {lat: 32.640008858753234, lng: 35.2028349054308},
      {lat: 32.63986832217509, lng: 35.20245343454008},
      {lat: 32.63988839836996, lng: 35.20207196495904}
    ].map(x => new L.LatLng(x.lat, x.lng)),
    _id: '5aa04c02e6529b0ff8c33386',
    poolId: 'game',
    type: 'obstacle'
  },
  {
    polygon: [
      {lat: 32.63894478917951, lng: 35.20538598349958},
      {lat: 32.6390451744538, lng: 35.20500451391854},
      {lat: 32.63912548104814, lng: 35.204789937197354},
      {lat: 32.63930617255177, lng: 35.20452767661482},
      {lat: 32.63930617255177, lng: 35.20409852317244},
      {lat: 32.63918571232513, lng: 35.203860105175416},
      {lat: 32.63934632629223, lng: 35.20376473745274},
      {lat: 32.639647478219686, lng: 35.20390778903675},
      {lat: 32.63984824487285, lng: 35.2040508393111},
      {lat: 32.6400690883326, lng: 35.20459920306167},
      {lat: 32.640289931247125, lng: 35.204956830057206},
      {lat: 32.640310008450236, lng: 35.2051952493639},
      {lat: 32.64022970181646, lng: 35.2055051924981},
      {lat: 32.640129318974246, lng: 35.20579129566614},
      {lat: 32.640289931247125, lng: 35.20612508138584},
      {lat: 32.64051077361643, lng: 35.20636349938286},
      {lat: 32.64055092681617, lng: 35.20648270969105},
      {lat: 32.6405710034093, lng: 35.206911863133435},
      {lat: 32.640370237826836, lng: 35.206959546994774},
      {lat: 32.640008858753234, lng: 35.20741254171299},
      {lat: 32.63972778537617, lng: 35.2074363842985},
      {lat: 32.639426633719054, lng: 35.207126439854626},
      {lat: 32.63912548104814, lng: 35.206768811549416},
      {lat: 32.638904635258825, lng: 35.205815136941965}
    ].map(x => new L.LatLng(x.lat, x.lng)),
    _id: '5aa04c02e6529b0ff8c33387',
    poolId: 'game',
    type: 'obstacle'
  },
  {
    polygon: [
      {lat: 32.64083199760681, lng: 35.20855695045612},
      {lat: 32.64083199760681, lng: 35.20884305362416},
      {lat: 32.640811921072284, lng: 35.20920068192936},
      {lat: 32.64067138575582, lng: 35.20939141737472},
      {lat: 32.640450544334456, lng: 35.20936757347955},
      {lat: 32.64035016063726, lng: 35.20927220575687},
      {lat: 32.64026985514236, lng: 35.20900994648401},
      {lat: 32.64008916558527, lng: 35.208962263932335},
      {lat: 32.64004901217826, lng: 35.20891457876133},
      {lat: 32.64004901217826, lng: 35.208676160764306},
      {lat: 32.64017772215188, lng: 35.20842567184446},
      {lat: 32.64035841153008, lng: 35.208580644066394},
      {lat: 32.640508985641205, lng: 35.208795220787586}
    ].map(x => new L.LatLng(x.lat, x.lng)),
    _id: '5aa04c02e6529b0ff8c33389',
    poolId: 'game',
    type: 'obstacle'
  },
  {
    polygon: [
      {lat: 32.63743900978184, lng: 35.20426541603229},
      {lat: 32.63767993587986, lng: 35.20400315544976},
      {lat: 32.63802124775233, lng: 35.20426541603229},
      {lat: 32.63806140206954, lng: 35.20467072819884},
      {lat: 32.637920862431905, lng: 35.204837621058694},
      {lat: 32.63794093906386, lng: 35.20526677450108},
      {lat: 32.63786063030329, lng: 35.205314458362416},
      {lat: 32.63759962688499, lng: 35.20524293322524}
    ].map(x => new L.LatLng(x.lat, x.lng)),
    _id: '5aa04c02e6529b0ff8c33388',
    poolId: 'game',
    type: 'obstacle'
  }
];


@Component({
  selector: 'app-amt-exp',
  templateUrl: './amt-exp.component.html',
  styleUrls: ['./amt-exp.component.scss']
})
export class AmtExpComponent implements OnInit {

  @Input() currentPool; /*: IPoolInfo;*/
  obstacles: IMapObject[];
  workerId: string;
  assignmentId: string;
  turkSubmitTo: string;
  hitId: string;
  timeAndScore: string;
  constructor(
    private poolService: PoolManagerService,
              private route: ActivatedRoute,
              public dialog: MatDialog) {
  }

  openDialog(): void {

    const dialogRef = this.dialog.open(InstructionsDialog1Component, {
      width: '400px'
    });

  }

  getObstacles(poolId: string) {
    this.poolService.getObstaclesByPool(poolId).subscribe(
      (obstacles: IMapObject[]) => {
        this.obstacles = obstacles;
      }
    );
  }

  getTimeAndScore(text: string) {
    this.timeAndScore = text;
  }

  openSubmitDialog(): void {
    const dialogRef = this.dialog.open(SubmitDialogComponent, {
      width: '350px',
      data: { assId: this.assignmentId, workerId: this.workerId }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  private mainVisability() {
    // main visibility API function
    // use visibility API to check if current tab is active or not
    let stateKey, eventKey;
      const keys = {
                  hidden: 'visibilitychange',
                  webkitHidden: 'webkitvisibilitychange',
                  mozHidden: 'mozvisibilitychange',
                  msHidden: 'msvisibilitychange'
      };
      for (stateKey in keys) {
          if (stateKey in document) {
              eventKey = keys[stateKey];
              break;
          }
      }
      return function(c) {
          if (c) {
            document.addEventListener(eventKey, c);
          }
          return !document[stateKey];
      };
  }

  checkForTabActivity(): void {
    const vis = this.mainVisability();
    // check if current tab is active or not
    vis(function() {
      if (vis(null)) {
        // tab is visible - has focus
        console.log('visible');
      } else {
        // tab is invisible - has blur
        console.log('invisible');
      }
    });
  }

  checkForWindowActivity() {
    // check if browser window has focus
    if (window.addEventListener) {
      window.addEventListener('focus', function (event) {
        // focus
        console.log('focus');
      }, false);
      window.addEventListener('blur', function (event) {
        // blur
        console.log('blur');
      }, false);
    }
  }

  ngOnInit() {
    /*
    this.poolService.getPools().subscribe(
      (pools: IPoolInfo[]) => {
        if (!this.currentPool) {
          this.currentPool = pools[5];
        }
        this.getObstacles(this.currentPool.poolId);
    });
    */
    this.currentPool = poolAMT;
    this.obstacles = obstaclesAMT;
    this.route.queryParams
        .subscribe(params => {
          this.workerId = params['workerId'];
          this.assignmentId = params['assignmentId'];
          this.hitId = params['hitId'];
          this.turkSubmitTo = params['turkSubmitTo'];
        });
    this.openDialog();
  }

}

