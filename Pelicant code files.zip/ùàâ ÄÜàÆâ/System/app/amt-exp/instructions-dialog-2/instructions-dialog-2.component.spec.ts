import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionsDialog2Component } from './instructions-dialog-2.component';

describe('InstructionsDialog2Component', () => {
  let component: InstructionsDialog2Component;
  let fixture: ComponentFixture<InstructionsDialog2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructionsDialog2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructionsDialog2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
