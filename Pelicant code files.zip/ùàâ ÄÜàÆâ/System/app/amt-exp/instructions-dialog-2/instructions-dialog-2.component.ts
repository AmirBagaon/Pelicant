import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';
import { InstructionsDialog3Component } from '../instructions-dialog-3/instructions-dialog-3.component';

@Component({
  selector: 'app-instructions-dialog-2',
  templateUrl: './instructions-dialog-2.component.html',
  styleUrls: ['./instructions-dialog-2.component.scss']
})
export class InstructionsDialog2Component implements OnInit {

  constructor(public dialogRef: MatDialogRef<InstructionsDialog2Component>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    onSubmit() {
      this.dialog.open(InstructionsDialog3Component, {
        width: '400px'
      });
    }
ngOnInit() {
}

}



