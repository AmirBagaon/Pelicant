import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-submit-dialog',
  templateUrl: './submit-dialog.component.html',
  styleUrls: ['./submit-dialog.component.scss']
})
export class SubmitDialogComponent implements OnInit {

  f: any;
  constructor(public dialogRef: MatDialogRef<SubmitDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any) { }

  onSubmit() {
    if (this.data.workerId) {
      this.f.submit();
    }
  }

  createForm() {
    this.f = document.createElement('form');
    this.f.setAttribute('method', 'post');
    this.f.setAttribute('action', 'https://workersandbox.mturk.com/mturk/externalSubmit');
    const i = document.createElement('input');
    i.setAttribute('type', 'hidden');
    i.setAttribute('value', this.data.assignmentId);
    i.setAttribute('name', 'assignmentId');
    this.f.appendChild(i);
    const i2 = document.createElement('input');
    i2.setAttribute('type', 'hidden');
    i2.setAttribute('value', 'bar');
    i2.setAttribute('name', 'foo');
    this.f.appendChild(i2);
    document.getElementsByTagName('body')[0].appendChild(this.f);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.createForm();
  }

}