import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionsDialog1Component } from './instructions-dialog-1.component';

describe('InstructionsDialog1Component', () => {
  let component: InstructionsDialog1Component;
  let fixture: ComponentFixture<InstructionsDialog1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructionsDialog1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructionsDialog1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
