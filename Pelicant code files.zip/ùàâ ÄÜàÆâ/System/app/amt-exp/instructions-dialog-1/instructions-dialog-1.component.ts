import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';
import { InstructionsDialog2Component } from '../instructions-dialog-2/instructions-dialog-2.component';

@Component({
  selector: 'app-instructions-dialog-1',
  templateUrl: './instructions-dialog-1.component.html',
  styleUrls: ['./instructions-dialog-1.component.scss']
})
export class InstructionsDialog1Component implements OnInit {

  constructor(public dialogRef: MatDialogRef<InstructionsDialog1Component>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    onSubmit() {
      this.dialog.open(InstructionsDialog2Component, {
        width: '400px'
      });
    }

    onNoClick(): void {
      this.dialogRef.close();
    }


ngOnInit() {
}

}



