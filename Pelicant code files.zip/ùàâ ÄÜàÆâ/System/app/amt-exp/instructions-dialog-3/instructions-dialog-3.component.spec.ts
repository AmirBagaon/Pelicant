import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionsDialog3Component } from './instructions-dialog-3.component';

describe('InstructionsDialog3Component', () => {
  let component: InstructionsDialog3Component;
  let fixture: ComponentFixture<InstructionsDialog3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructionsDialog3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructionsDialog3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
