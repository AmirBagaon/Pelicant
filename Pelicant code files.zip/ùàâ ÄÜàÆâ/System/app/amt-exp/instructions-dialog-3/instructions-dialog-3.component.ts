import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-instructions-dialog-3',
  templateUrl: './instructions-dialog-3.component.html',
  styleUrls: ['./instructions-dialog-3.component.scss']
})
export class InstructionsDialog3Component implements OnInit {

  constructor(public dialogRef: MatDialogRef<InstructionsDialog3Component>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

ngOnInit() {
}

}



