import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmtExpComponent } from './amt-exp.component';

describe('AmtExpComponent', () => {
  let component: AmtExpComponent;
  let fixture: ComponentFixture<AmtExpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmtExpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmtExpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
