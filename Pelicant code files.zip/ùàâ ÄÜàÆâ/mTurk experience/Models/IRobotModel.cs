﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//An interface of a robot model
namespace Pelicant.Models
{
    interface IRobotModel
    {

        JObject getLocation();
        string getBattery();
        string getMessage();
        string getStatus();
    }
}
